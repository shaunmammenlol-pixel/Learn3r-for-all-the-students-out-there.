import type { ChatMessage, StudyQuestion } from '@workspace/api-client-react';

export interface QuizAttempt {
  answer: string;
  status: 'correct' | 'partial' | 'incorrect';
  explanation: string;
}

export type QuestionAttempts = Record<string, QuizAttempt[]>;

export function isSolved(attempts: QuizAttempt[] = []): boolean {
  return attempts.at(-1)?.status === 'correct';
}

export function earnedMarks(question: StudyQuestion, attempts: QuizAttempt[] = []): number {
  const first = attempts[0];
  return first?.status === 'correct' ? question.marks : first?.status === 'partial' ? Math.floor(question.marks / 2) : 0;
}

export function quizScore(questions: StudyQuestion[], attempts: QuestionAttempts) {
  return {
    earned: questions.reduce((sum, question) => sum + earnedMarks(question, attempts[question.id]), 0),
    available: questions.reduce((sum, question) => sum + question.marks, 0),
  };
}

export function validQuestionAttempts(value: unknown, questions: StudyQuestion[]): value is QuestionAttempts {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;
  return Object.entries(value).every(([id, attempts]) => questions.some((question) => question.id === id) &&
    Array.isArray(attempts) && attempts.every((attempt) =>
      typeof attempt === 'object' && attempt !== null &&
      typeof attempt.answer === 'string' && attempt.answer.trim().length > 0 && attempt.answer.length <= 5000 &&
      ['correct', 'partial', 'incorrect'].includes(attempt.status) &&
      typeof attempt.explanation === 'string' && attempt.explanation.length > 0 && attempt.explanation.length <= 5000));
}

/** Preserve first-attempt answers from sessions created before retry progression. */
export function migrateQuizProgress(questions: StudyQuestion[], history: ChatMessage[]) {
  const attempts: QuestionAttempts = {};
  let index = 0;
  history.forEach((message, position) => {
    if (message.role !== 'user') return;
    const question = questions[index++];
    if (!question) return;
    const feedback = history[position + 1];
    const status = feedback?.answer_status;
    if (!status) return;
    attempts[question.id] = [{
      answer: message.content, status,
      explanation: feedback.content.split('\n\nQuestion ')[0] || question.explanation,
    }];
  });
  const firstUnsolved = questions.findIndex((question) => !isSolved(attempts[question.id]));
  return { question_attempts: attempts, question_index: firstUnsolved < 0 ? questions.length : firstUnsolved };
}
