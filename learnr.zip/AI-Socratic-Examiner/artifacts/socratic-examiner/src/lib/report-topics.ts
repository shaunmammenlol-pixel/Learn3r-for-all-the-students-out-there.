import type { ReportResult, StudyQuestion } from '@workspace/api-client-react';
import type { QuestionAttempts } from './quiz-progress';

/** Keep revision grounded in recorded answers, even when the AI omits topics. */
export function buildReviewTopics(
  reported: ReportResult['misunderstood_topics'],
  questions: StudyQuestion[],
  attempts: QuestionAttempts,
): ReportResult['misunderstood_topics'] {
  const topicKey = (topic: string) => topic.trim().toLowerCase();
  const topics = new Map(reported.map((item) => [topicKey(item.topic), item]));

  for (const question of questions) {
    const answers = attempts[question.id] ?? [];
    const first = answers[0];
    if (!first || first.status === 'correct') continue;

    const evidence = [
      `Your first answer (${first.status === 'partial' ? 'partly correct' : 'incorrect'}): ${first.answer}`,
      `Expected answer: ${question.correct_answer}`,
      `Why: ${question.explanation}`,
      answers.at(-1)?.status === 'correct'
        ? 'You got this right after practice. Revisit it once more to strengthen your recall.'
        : 'Review this explanation, then try answering again in your own words.',
    ].join('\n\n');
    topics.set(topicKey(question.prompt), { topic: question.prompt, evidence });
  }
  return [...topics.values()];
}
