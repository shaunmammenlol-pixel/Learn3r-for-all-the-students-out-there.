import type { QuizAttempt } from './quiz-progress';

/** Do not trust generated or previously saved retry feedback to be spoiler-free. */
export function quizFeedback(status: QuizAttempt['status'], explanation: string, attemptIndex = 0): string {
  if (status === 'correct') return explanation;
  const hints = status === 'partial' ? [
    'You have part of the idea right. Check that your answer covers every part of the question, then try adding what is missing. You can build on this.',
    'There is a useful idea in your answer. Read the question slowly and check your wording against your notes. Take your time with another try.',
    'You are making progress. Try breaking the question into smaller parts and answering each part in your own words.',
  ] : [
    'Not quite yet—and that’s okay. Reread what the question asks and find the matching detail in your notes. Try again when you’re ready.',
    'Another try is part of learning. Compare your answer with the relevant part of your notes and check for a detail you may have mixed up.',
    'You do not need to rush. Read the question one part at a time, then explain your thinking in your own words.',
  ];
  return hints[Math.max(0, attemptIndex) % hints.length];
}

export function quizMotivation(questionIndex: number, total: number, solved: boolean, attempts: number): string {
  if (solved && questionIndex === total - 1) return 'You’ve worked through every question. Take a breath, then see how you did.';
  if (solved) return [
    'One more step forward. Let the explanation settle, then keep going when you’re ready.',
    'You worked through that one. Carry that patience into the next question.',
    'Your effort is adding up. A short pause is welcome before the next question.',
  ][questionIndex % 3];
  if (attempts) return 'Needing another try is normal. Keep going—this is practice, not a race.';
  if (questionIndex === 0) return 'Start with what you know. You can take this one question at a time.';
  return [
    'Keep going at your own pace. Each question is another chance to practise.',
    'You’ve already made a start. Focus on just this next step.',
    'Small steps count. Take a breath and give this question your attention.',
  ][(questionIndex - 1) % 3];
}
