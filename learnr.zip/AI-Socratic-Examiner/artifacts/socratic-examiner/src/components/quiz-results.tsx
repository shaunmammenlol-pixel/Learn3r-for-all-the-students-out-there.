import type { StudyQuestion } from '@workspace/api-client-react';
import { earnedMarks, quizScore } from '@/lib/quiz-progress';
import type { QuestionAttempts } from '@/lib/quiz-progress';

interface QuizResultsProps {
  questions: StudyQuestion[];
  attempts: QuestionAttempts;
}

const statusLabel = { correct: 'Correct', partial: 'Partly correct', incorrect: 'Not yet right' } as const;

const preserved = 'whitespace-pre-wrap break-words [overflow-wrap:anywhere]';

export function QuizResults({ questions, attempts }: QuizResultsProps) {
  const { earned, available } = quizScore(questions, attempts);

  return (
    <section className="enter space-y-6" data-testid="quiz-results" aria-labelledby="quiz-results-heading">
      <div className="surface rounded-xl p-6 sm:p-8">
        <p className="eyebrow">Results</p>
        <h2 id="quiz-results-heading" className="serif mt-2 text-2xl font-semibold sm:text-3xl">
          You completed every question.
        </h2>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          Your score reflects your first answers, so it shows what to revisit.
        </p>
        <div className="mt-6 flex flex-wrap items-baseline gap-x-3 gap-y-1" data-testid="quiz-total-score" aria-label={`Total score ${earned} out of ${available} marks`}>
          <span className="serif text-5xl font-bold text-primary" data-testid="text-earned-marks">{earned}</span>
          <span className="serif text-2xl text-muted-foreground">/ {available} marks</span>
        </div>
        <div className="mt-6 rounded-lg border bg-muted/50 p-4 text-sm" data-testid="text-scoring-explanation">
          <p className="font-semibold">How scoring works</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-muted-foreground">
            <li>Your first submitted answer to each question decides its marks.</li>
            <li>A correct first answer earns the full marks.</li>
            <li>A partly correct first answer earns half the marks, rounded down.</li>
            <li>An incorrect first answer earns 0.</li>
            <li>Retries are for learning and never raise the score.</li>
          </ul>
        </div>
      </div>

      <ol className="space-y-4">
        {questions.map((question, index) => {
          const list = attempts[question.id] ?? [];
          const first = list[0];
          const retries = list.slice(1);
          const got = earnedMarks(question, list);
          return (
            <li key={question.id}>
              <article className="surface rounded-xl p-5 sm:p-6" data-testid={`review-question-${index}`}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <p className="eyebrow">Question {index + 1}</p>
                  <p className="text-sm font-semibold" data-testid={`review-marks-${index}`}>
                    {got} of {question.marks} {question.marks === 1 ? 'mark' : 'marks'} earned
                  </p>
                </div>
                <h3 className={`serif mt-2 text-lg font-semibold ${preserved}`}>{question.prompt}</h3>

                <dl className="mt-4 space-y-4 text-sm">
                  <div>
                    <dt className="font-semibold">Your first answer</dt>
                    <dd className={`mt-1 rounded-lg bg-muted/60 p-3 ${preserved}`} data-testid={`review-first-answer-${index}`}>
                      {first ? first.answer : 'No answer was submitted.'}
                    </dd>
                  </div>
                  <div>
                    <dt className="font-semibold">Expected answer</dt>
                    <dd className={`mt-1 rounded-lg bg-accent p-3 text-accent-foreground ${preserved}`} data-testid={`review-expected-${index}`}>
                      {question.correct_answer}
                    </dd>
                  </div>
                  <div>
                    <dt className="font-semibold">Simple explanation</dt>
                    <dd className={`mt-1 text-muted-foreground ${preserved}`}>{question.explanation}</dd>
                  </div>
                  {first && (
                    <div>
                      <dt className="font-semibold">
                        First attempt feedback{' '}
                        <span className="font-normal text-muted-foreground">({statusLabel[first.status]})</span>
                      </dt>
                      <dd className={`mt-1 text-muted-foreground ${preserved}`} data-testid={`review-first-feedback-${index}`}>
                        {first.status === 'correct'
                          ? first.explanation
                          : `Where it slipped: ${first.explanation}`}
                      </dd>
                    </div>
                  )}
                </dl>

                {retries.length > 0 && (
                  <details className="mt-4 rounded-lg border p-3 text-sm" data-testid={`review-retries-${index}`}>
                    <summary className="cursor-pointer font-semibold">
                      Later attempts ({retries.length}) - practice only, not scored
                    </summary>
                    <ol className="mt-3 space-y-3">
                      {retries.map((retry, r) => (
                        <li key={r} className="rounded-lg bg-muted/50 p-3">
                          <p className="font-semibold">
                            Retry {r + 1} <span className="font-normal text-muted-foreground">({statusLabel[retry.status]})</span>
                          </p>
                          <p className={`mt-1 ${preserved}`}>{retry.answer}</p>
                          <p className={`mt-2 text-muted-foreground ${preserved}`}>{retry.explanation}</p>
                        </li>
                      ))}
                    </ol>
                  </details>
                )}
              </article>
            </li>
          );
        })}
      </ol>
    </section>
  );
}

export default QuizResults;
