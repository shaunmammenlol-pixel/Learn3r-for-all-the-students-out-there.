import { useRef, useState } from 'react';
import type { ChangeEvent } from 'react';
import { FileText, Headphones, Loader2 } from 'lucide-react';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

interface PuterSpeech {
  ai: {
    speech2txt(file: File, options: { response_format: 'text' }): Promise<unknown>;
  };
}

interface SourceImporterProps {
  hasDraft: boolean;
  disabled: boolean;
  onUseText: (text: string, mode: 'replace' | 'append') => void;
}

const PDF_LIMIT = 20 * 1024 * 1024;
const AUDIO_LIMIT = 10 * 1024 * 1024;

export function SourceImporter({ hasDraft, disabled, onUseText }: SourceImporterProps) {
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [importedText, setImportedText] = useState('');
  const [fileName, setFileName] = useState('');
  const requestId = useRef(0);

  async function readPdf(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setError('');
    setNotice('');
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      setError('Please choose a PDF file.');
      return;
    }
    if (file.size > PDF_LIMIT) {
      setError('Choose a PDF smaller than 20 MB.');
      return;
    }
    const id = ++requestId.current;
    setBusy(true);
    let task: ReturnType<typeof import('pdfjs-dist').getDocument> | undefined;
    try {
      const pdfjs = await import('pdfjs-dist');
      pdfjs.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;
      task = pdfjs.getDocument({ data: await file.arrayBuffer() });
      const pdf = await task.promise;
      if (pdf.numPages > 100) throw new Error('Choose a PDF with 100 pages or fewer.');
      const pages: string[] = [];
      let emptyPages = 0;
      for (let index = 1; index <= pdf.numPages; index += 1) {
        const page = await pdf.getPage(index);
        const content = await page.getTextContent();
        const text = content.items.map((item) => 'str' in item ? `${item.str}${item.hasEOL ? '\n' : ' '}` : '').join('').trim();
        pages.push(text);
        if (!text) emptyPages += 1;
        page.cleanup();
      }
      const text = pages.join('\n\n').trim();
      if (!text) throw new Error('No selectable text was found. Scanned or image-only PDFs need OCR first; please upload a text-based PDF.');
      if (id === requestId.current) {
        setImportedText(text);
        setFileName(file.name);
        setNotice(emptyPages ? `${emptyPages} page(s) had no selectable text. Check the preview for missing scanned content.` : 'PDF text extracted locally. Check reading order and formatting before using it.');
      }
    } catch (cause) {
      setError(cause instanceof Error && cause.name === 'PasswordException'
        ? 'This PDF is password-protected. Upload an unlocked copy.'
        : cause instanceof Error ? cause.message : 'The PDF could not be read. Try a different text-based PDF.');
    } finally {
      await task?.destroy();
      if (id === requestId.current) setBusy(false);
    }
  }

  function chooseAudio(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setError('');
    setNotice('');
    if (!/\.(mp3|wav|m4a|aac|ogg|oga|opus|webm|flac|aiff?|mpeg|mp4)$/i.test(file.name)) {
      setError('Choose an MP3, WAV, M4A, AAC, OGG, Opus, WebM, FLAC, AIFF, or MP4 voice note.');
      return;
    }
    if (file.size > AUDIO_LIMIT) {
      setError('Choose a voice note smaller than 10 MB.');
      return;
    }
    setAudioFile(file);
  }

  async function transcribe() {
    if (!audioFile || busy) return;
    const puter = (window as Window & { puter?: PuterSpeech }).puter;
    if (!puter?.ai?.speech2txt) {
      setError('Puter has not loaded. Check your connection or content blocker, reload the page, and try again.');
      return;
    }
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const result = await puter.ai.speech2txt(audioFile, { response_format: 'text' });
      const text = typeof result === 'string' ? result : result && typeof result === 'object' && 'text' in result && typeof result.text === 'string' ? result.text : '';
      if (!text.trim()) throw new Error('Puter returned no transcript. Try a clearer or shorter voice note.');
      setImportedText(text.trim());
      setFileName(audioFile.name);
      setNotice('Transcription complete. Review the wording before using it as study material.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Puter could not transcribe this file. Check sign-in, available usage, and the audio format, then try again.');
    } finally {
      setBusy(false);
    }
  }

  function useText(mode: 'replace' | 'append') {
    onUseText(importedText, mode);
    setImportedText('');
    setNotice('Imported text added to your source draft. Review it, then begin your study.');
  }

  return <section className="mb-5 rounded-xl border border-border bg-muted/25 p-4" aria-label="Import study material">
    <p className="text-sm font-semibold">Import from PDF or voice note</p>
    <div className="mt-3 flex flex-wrap gap-2">
      <label className={`quiet-button inline-flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold ${busy || disabled ? 'pointer-events-none opacity-50' : ''}`}>
        <FileText size={15} />Upload PDF
        <input type="file" accept=".pdf,application/pdf" className="sr-only" disabled={busy || disabled} onChange={readPdf} aria-label="Upload PDF source" data-testid="input-pdf-source" />
      </label>
      <label className={`quiet-button inline-flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold ${busy || disabled ? 'pointer-events-none opacity-50' : ''}`}>
        <Headphones size={15} />Upload voice note
        <input type="file" accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.opus,.webm,.flac,.aiff,.mp4" className="sr-only" disabled={busy || disabled} onChange={chooseAudio} aria-label="Upload voice note source" data-testid="input-audio-source" />
      </label>
    </div>
    <p className="mt-2 text-[11px] leading-5 text-muted-foreground">Text PDFs: up to 20 MB / 100 pages, read in your browser. Audio: up to 10 MB, sent to Puter for transcription. Puter may require sign-in and usage authorization on your account.</p>
    {audioFile && <div className="mt-3 rounded-lg border border-border bg-background p-3">
      <p className="break-all text-xs font-medium">{audioFile.name}</p>
      <button type="button" onClick={transcribe} disabled={busy || disabled} className="primary-button mt-2 inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold" data-testid="button-transcribe-note">Transcribe with Puter</button>
    </div>}
    {busy && <p role="status" className="mt-3 flex items-center gap-2 text-xs text-primary"><Loader2 size={14} className="animate-spin" />Importing… please keep this page open.</p>}
    {error && <p role="alert" className="mt-3 text-xs leading-5 text-destructive" data-testid="status-import-error">{error}</p>}
    {notice && <p role="status" className="mt-3 text-xs leading-5 text-muted-foreground">{notice}</p>}
    {importedText && <div className="mt-3" data-testid="import-preview">
      <label htmlFor="import-preview" className="text-xs font-semibold">Review extracted text — {fileName}</label>
      <textarea id="import-preview" value={importedText} onChange={(event) => setImportedText(event.target.value)} rows={5} className="mt-2 w-full rounded-lg border border-input bg-background p-3 text-xs leading-5" />
      <p className="mt-1 text-[11px] text-muted-foreground">{importedText.length.toLocaleString()} characters. Input is limited to 5,000; trim long text before continuing.</p>
      <div className="mt-3 flex flex-wrap gap-2">
        <button type="button" disabled={busy || disabled} onClick={() => useText('replace')} className="primary-button rounded-lg px-3 py-2 text-xs font-semibold" data-testid="button-use-import">{hasDraft ? 'Replace draft with this text' : 'Use this text'}</button>
        {hasDraft && <button type="button" disabled={busy || disabled} onClick={() => useText('append')} className="quiet-button rounded-lg px-3 py-2 text-xs font-semibold" data-testid="button-append-import">Append to draft</button>}
        <button type="button" onClick={() => setImportedText('')} className="quiet-button rounded-lg px-3 py-2 text-xs font-semibold">Discard import</button>
      </div>
    </div>}
  </section>;
}
