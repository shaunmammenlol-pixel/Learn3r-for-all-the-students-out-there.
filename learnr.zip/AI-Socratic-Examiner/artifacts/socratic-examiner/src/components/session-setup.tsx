import { useId, useState } from 'react';
import type { FormEvent } from 'react';
import { AlertCircle, ArrowRight, CircleHelp, Layers, ListChecks, PenLine } from 'lucide-react';

type Mode = 'quiz' | 'qa' | 'mixed';

interface SessionSetupProps {
  onStart: (mcqCount: number, qaCount: number) => void;
  pending: boolean;
  hasExistingAnswers: boolean;
}

const MAX_TOTAL = 20;

const MODES: { value: Mode; label: string; hint: string; icon: typeof ListChecks }[] = [
  { value: 'quiz', label: 'Quiz', hint: 'Multiple choice', icon: ListChecks },
  { value: 'qa', label: 'Q&A', hint: 'Written answers in your own words', icon: PenLine },
  { value: 'mixed', label: 'Mixed', hint: 'A blend of both styles', icon: Layers },
];

function parseCount(raw: string): number | null {
  if (!/^\d+$/.test(raw.trim())) return null;
  return Number(raw.trim());
}

export function SessionSetup({ onStart, pending, hasExistingAnswers }: SessionSetupProps) {
  const uid = useId();
  const [mode, setMode] = useState<Mode>('quiz');
  const [single, setSingle] = useState('5');
  const [mcq, setMcq] = useState('3');
  const [qa, setQa] = useState('3');

  const singleN = parseCount(single);
  const mcqN = parseCount(mcq);
  const qaN = parseCount(qa);

  let singleError = '';
  let mcqError = '';
  let qaError = '';
  let totalError = '';
  if (mode === 'mixed') {
    if (mcqN === null || mcqN < 1) mcqError = 'Enter a whole number of 1 or more.';
    if (qaN === null || qaN < 1) qaError = 'Enter a whole number of 1 or more.';
    if (!mcqError && !qaError && (mcqN as number) + (qaN as number) > MAX_TOTAL) {
      totalError = `Total must be ${MAX_TOTAL} or fewer. You have ${(mcqN as number) + (qaN as number)}.`;
    }
  } else if (singleN === null || singleN < 1 || singleN > MAX_TOTAL) {
    singleError = `Enter a whole number from 1 to ${MAX_TOTAL}.`;
  }
  const invalid = Boolean(singleError || mcqError || qaError || totalError);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (invalid || pending) return;
    if (mode === 'quiz') onStart(singleN as number, 0);
    else if (mode === 'qa') onStart(0, singleN as number);
    else onStart(mcqN as number, qaN as number);
  }

  const inputCls = 'w-full rounded-xl border bg-background px-4 py-3 text-sm outline-none transition focus:border-primary';
  const field = (id: string, label: string, value: string, set: (v: string) => void, error: string, testid: string) => (
    <div>
      <label htmlFor={id} className="mb-2 block text-sm font-semibold">{label}</label>
      <input id={id} type="number" inputMode="numeric" min={1} max={MAX_TOTAL} step={1} value={value}
        onChange={(e) => set(e.target.value)} disabled={pending}
        aria-invalid={Boolean(error) || undefined} aria-describedby={error ? `${id}-err` : undefined}
        className={`${inputCls} ${error ? 'border-destructive' : 'border-input'}`} data-testid={testid} />
      {error && <p id={`${id}-err`} role="alert" className="mt-2 flex items-start gap-1.5 text-xs text-destructive"><AlertCircle size={14} className="mt-px shrink-0" />{error}</p>}
    </div>
  );

  return (
    <form onSubmit={submit} className="surface enter mx-auto max-w-2xl rounded-2xl p-5 sm:p-7" data-testid="form-session-setup" aria-busy={pending}>
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <p className="eyebrow">Practice setup</p>
          <h1 className="serif mt-2 text-3xl tracking-tight">Choose your questions</h1>
          <p className="mt-2 text-sm leading-6 text-muted-foreground">Questions come only from your notes.</p>
        </div>
        <span className="hidden h-10 w-10 shrink-0 place-items-center rounded-xl bg-secondary text-primary sm:grid"><CircleHelp size={18} /></span>
      </div>

      <fieldset disabled={pending} className="min-w-0 border-0 p-0">
        <legend className="mb-3 text-sm font-semibold">Question style</legend>
        <div role="radiogroup" aria-label="Question style" className="grid gap-3 sm:grid-cols-3">
          {MODES.map(({ value, label, hint, icon: Icon }) => {
            const active = mode === value;
            return (
              <label key={value} className={`relative flex cursor-pointer flex-col gap-2 rounded-xl border p-4 transition focus-within:outline focus-within:outline-[3px] focus-within:outline-offset-2 focus-within:outline-ring/55 ${active ? 'border-primary bg-primary/5' : 'border-input bg-background hover:bg-muted'}`}>
                <input type="radio" name={`${uid}-mode`} value={value} checked={active} onChange={() => setMode(value)}
                  className="sr-only" data-testid={`radio-mode-${value}`} />
                <span className={`grid h-8 w-8 place-items-center rounded-lg ${active ? 'bg-primary text-primary-foreground' : 'bg-secondary text-primary'}`}><Icon size={16} /></span>
                <span className="text-sm font-bold">{label}</span>
                <span className="text-xs leading-5 text-muted-foreground">{hint}</span>
              </label>
            );
          })}
        </div>

        <div className="mt-6">
          {mode === 'mixed' ? (
            <div className="grid gap-4 sm:grid-cols-2">
              {field(`${uid}-mcq`, 'Multiple choice', mcq, setMcq, mcqError, 'input-mcq-count')}
              {field(`${uid}-qa`, 'Written answer questions', qa, setQa, qaError, 'input-qa-count')}
            </div>
          ) : field(`${uid}-n`, mode === 'quiz' ? 'Number of multiple choice questions' : 'Number of written questions', single, setSingle, singleError, 'input-question-count')}
          {totalError && <p role="alert" className="mt-3 flex items-start gap-1.5 text-xs text-destructive" data-testid="error-total-count"><AlertCircle size={14} className="mt-px shrink-0" />{totalError}</p>}
          <p className="mt-3 text-xs text-muted-foreground">
            {mode === 'mixed' ? `Up to ${MAX_TOTAL} questions in total.` : `1 to ${MAX_TOTAL} questions.`}
          </p>
        </div>
      </fieldset>

      {hasExistingAnswers && (
        <div role="alert" className="mt-6 flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm" data-testid="warning-replace-answers">
          <AlertCircle size={17} className="mt-0.5 shrink-0 text-destructive" />
          <p>A new set replaces your current answers and progress.</p>
        </div>
      )}

      <button type="submit" disabled={invalid || pending} className="primary-button mt-7 flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3.5 text-sm font-bold" data-testid="button-start-session">
        {pending ? <><span className="h-4 w-4 animate-pulse rounded-full bg-current/50" />Generating questions…</> : <>Start session <ArrowRight size={17} /></>}
      </button>
      <p role="status" className="sr-only">{pending ? 'Generating your questions' : ''}</p>
    </form>
  );
}

export default SessionSetup;
