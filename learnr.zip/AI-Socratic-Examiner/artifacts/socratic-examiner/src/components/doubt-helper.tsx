import { useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { MessageCircle } from 'lucide-react';
import { getResolveDoubtUrl } from '@workspace/api-client-react';

// All request state is represented by this string union, never boolean flags.
export type DoubtState = 'idle' | 'loading' | 'success' | 'error';
type DoubtMessage = { role: 'user' | 'agent'; text: string };

export default function DoubtPanel({ sourceMaterial }: { sourceMaterial: string }) {
  const [doubtState, setDoubtState] = useState<DoubtState>('idle');
  const [doubtText, setDoubtText] = useState('');
  const [chatLog, setChatLog] = useState<DoubtMessage[]>([]);
  const chatContainer = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatContainer.current) chatContainer.current.scrollTop = chatContainer.current.scrollHeight;
  }, [chatLog, doubtState]);

  async function handleAskDoubt(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (doubtText.trim() === '' || doubtState === 'loading') return;
    const question = doubtText.trim();
    setDoubtState('loading');
    setChatLog((previous) => [...previous, { role: 'user', text: question }]);
    try {
      const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
      const response = await fetch(`${basePath}${getResolveDoubtUrl()}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source_material: sourceMaterial, user_doubt: question }),
        signal: AbortSignal.timeout(40000),
      });
      const data: unknown = await response.json();
      if (typeof data !== 'object' || data === null || !('status' in data) ||
        !('reply' in data) || typeof data.reply !== 'string' || !data.reply.trim() ||
        (data.status !== 'success' && data.status !== 'error')) {
        setDoubtState('error');
        setChatLog((previous) => [...previous, { role: 'agent', text: 'The TA returned an unreadable response. Please try again later.' }]);
      } else if (!response.ok || data.status === 'error') {
        setDoubtState('error');
        setChatLog((previous) => [...previous, { role: 'agent', text: `Connection error. ${data.reply}` }]);
      } else {
        const reply = data.reply;
        setDoubtState('success');
        setChatLog((previous) => [...previous, { role: 'agent', text: reply }]);
        setDoubtText('');
      }
    } catch {
      setDoubtState('error');
      setChatLog((previous) => [...previous, { role: 'agent', text: 'Network failure. Please try again later; your quiz progress is unchanged.' }]);
    }
  }

  return <article className="surface flex w-full flex-col gap-4 rounded-2xl p-5" data-testid="doubt-helper" data-doubt-state={doubtState}>
    <div>
      <div className="flex items-center gap-2"><MessageCircle size={18} className="text-primary" /><h2 className="text-sm font-bold">Doubt helper</h2></div>
      <p className="mt-2 text-xs leading-5 text-muted-foreground">Something unclear? Ask in your own words. Your notes and question go to an AI helper; some may need Lead TA review.</p>
    </div>
    <div ref={chatContainer} className="flex h-64 flex-col gap-3 overflow-y-auto rounded-xl border border-border bg-background/50 p-3"
      role="log" aria-label="Doubt conversation" aria-live="polite" aria-relevant="additions" aria-busy={doubtState === 'loading'} data-testid="doubt-chat-log">
      {chatLog.length === 0 && <p className="text-xs leading-6 text-muted-foreground">Something unclear? Ask below.</p>}
      {chatLog.map((message, index) => <div key={index}
        className={`max-w-[90%] whitespace-pre-wrap break-words rounded-xl p-3 text-sm leading-6 ${message.role === 'user' ? 'self-end bg-primary text-primary-foreground' : 'self-start bg-muted text-foreground'}`}
        data-testid={`doubt-message-${index}`}>
        <p className="mb-1 text-[10px] font-bold uppercase tracking-wider opacity-75">{message.role === 'user' ? 'You' : 'Helper'}</p>
        {message.text}
      </div>)}
      {doubtState === 'loading' && <p className="text-xs text-muted-foreground" role="status">Helper is replying…</p>}
    </div>
    {doubtState === 'error' && <p className="text-xs text-destructive" role="alert">Could not reach the helper. See the message above.</p>}
    <form onSubmit={handleAskDoubt} className="space-y-3">
      <label htmlFor="helper-doubt" className="block text-xs font-semibold">What would you like help with?</label>
      <textarea id="helper-doubt" rows={4} value={doubtText} onChange={(event) => setDoubtText(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === 'Enter' && (event.ctrlKey || event.metaKey) && !event.nativeEvent.isComposing) {
            event.preventDefault();
            event.currentTarget.form?.requestSubmit();
          }
        }}
        maxLength={2000} disabled={doubtState === 'loading'} placeholder="Tell me which part feels confusing. You can write a few lines…"
        aria-describedby="helper-doubt-hint helper-doubt-count"
        className="block max-h-60 min-h-[112px] w-full resize-y rounded-xl border border-input bg-background px-3 py-3 text-sm leading-6 outline-none focus:border-primary disabled:opacity-60"
        data-testid="input-doubt" />
      <div className="flex items-center justify-between gap-3 text-[11px] text-muted-foreground">
        <span id="helper-doubt-hint">Enter for a new line.</span>
        <span id="helper-doubt-count" className="shrink-0">{doubtText.length.toLocaleString()} / 2,000</span>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <span className="text-[11px] text-muted-foreground">Ctrl / ⌘ + Enter to send</span>
        <button type="submit" className="primary-button rounded-lg px-4 py-2 text-sm font-bold"
          disabled={doubtState === 'loading' || doubtText.trim() === ''} data-testid="button-resolve-doubt">{doubtState === 'loading' ? 'Sending…' : 'Ask helper'}</button>
      </div>
    </form>
  </article>;
}
