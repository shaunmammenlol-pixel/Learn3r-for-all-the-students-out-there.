import { useEffect, useRef } from 'react';

export interface StudyScrollState {
  view: string;
  questionId?: string;
  attempts: number;
  loading: boolean;
  complete: boolean;
  error: string;
}
type ScrollTarget = 'page' | 'question' | 'feedback' | 'loading' | 'error';

export function getStudyScrollTarget(previous: StudyScrollState | null, current: StudyScrollState): ScrollTarget | null {
  if (current.error && current.error !== previous?.error) return 'error';
  if (!previous || previous.view !== current.view) {
    return current.view === 'quiz' && current.questionId ? 'question' : 'page';
  }
  if (current.view !== 'quiz') return null;
  if (previous.questionId !== current.questionId || previous.complete !== current.complete) {
    return current.complete ? 'page' : 'question';
  }
  if (current.attempts > previous.attempts) return 'feedback';
  if (current.loading && !previous.loading) return 'loading';
  return null;
}

export function useStudyScroll({ view, questionId, attempts, loading, complete, error }: StudyScrollState) {
  const page = useRef<HTMLElement>(null);
  const question = useRef<HTMLElement>(null);
  const feedback = useRef<HTMLDivElement>(null);
  const pending = useRef<HTMLDivElement>(null);
  const errorBanner = useRef<HTMLDivElement>(null);
  const previous = useRef<StudyScrollState | null>(null);

  useEffect(() => {
    const current = { view, questionId, attempts, loading, complete, error };
    const destination = getStudyScrollTarget(previous.current, current);
    if (!destination) {
      previous.current = current;
      return;
    }
    const frame = window.requestAnimationFrame(() => {
      // Commit here so Strict Mode's cancelled first frame does not consume navigation.
      previous.current = current;
      const element = {
        page: page.current, question: question.current, feedback: feedback.current,
        loading: pending.current, error: errorBanner.current,
      }[destination] ?? page.current;
      const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      element?.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'start', inline: 'nearest' });
      if (destination !== 'loading') element?.focus({ preventScroll: true });
    });
    return () => window.cancelAnimationFrame(frame);
  }, [view, questionId, attempts, loading, complete, error]);

  return { page, question, feedback, pending, errorBanner };
}
