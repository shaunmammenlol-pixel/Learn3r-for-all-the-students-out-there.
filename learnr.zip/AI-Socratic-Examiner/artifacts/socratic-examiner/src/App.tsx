import { useEffect, useMemo, useRef, useState } from 'react';
import type { FormEvent, ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useCreateStudyReport, useCreateQuestionSet, useEvaluateAnswer, useProcessSourceMaterial } from '@workspace/api-client-react';
import type { ChatMessage, MessageKind, ProcessResult, ReportResult, StudyQuestion } from '@workspace/api-client-react';
import { AlertCircle, ArrowLeft, ArrowRight, BookOpen, Check, CheckCircle2, CircleHelp, FileText, Lightbulb, Mic, MicOff, Moon, PanelTop, RefreshCw, Send, Sun, Target, TrendingUp } from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { SourceImporter } from '@/components/source-importer';
import { SessionSetup } from '@/components/session-setup';
import { QuizResults } from '@/components/quiz-results';
import DoubtPanel from '@/components/doubt-helper';
import { isSolved, migrateQuizProgress, validQuestionAttempts } from '@/lib/quiz-progress';
import { buildReviewTopics } from '@/lib/report-topics';
import { quizFeedback, quizMotivation } from '@/lib/quiz-feedback';
import { useStudyScroll } from '@/hooks/use-study-scroll';
import type { QuestionAttempts, QuizAttempt } from '@/lib/quiz-progress';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import './index.css';

type AppView = 'input' | 'study-guide' | 'setup' | 'dashboard' | 'quiz' | 'report';
type AnswerStatus = 'correct' | 'partial' | 'incorrect';
type MasteryStatus = 'yes' | 'no';
type RequestStatus = 'idle' | 'loading' | 'success' | 'error';
type Theme = 'light' | 'dark';
type MessageKindValue = MessageKind;

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike extends ArrayLike<SpeechRecognitionAlternativeLike> {
  isFinal: boolean;
}

interface SpeechRecognitionEventLike {
  results: ArrayLike<SpeechRecognitionResultLike>;
  resultIndex: number;
}

interface SpeechRecognitionErrorLike {
  error: string;
}

interface SpeechRecognitionLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorLike) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}

interface SpeechRecognitionConstructor {
  new(): SpeechRecognitionLike;
}

type SpeechRecognitionWindow = Window & {
  SpeechRecognition?: SpeechRecognitionConstructor;
  webkitSpeechRecognition?: SpeechRecognitionConstructor;
};

interface Session {
  source_material: string;
  chat_history: ChatMessage[];
  mastery_index: number;
  topic_scores: Record<string, number>;
  app_view: AppView;
  study_guide_seen: boolean;
  theme: Theme;
  report_result: ReportResult | null;
  process_result: ProcessResult | null;
  question_set: StudyQuestion[];
  question_index: number;
  question_attempts: QuestionAttempts;
}

const STORAGE_KEY = 'socratic-examiner-session';
const queryClient = new QueryClient();
const emptySession: Session = {
  source_material: '',
  chat_history: [],
  mastery_index: 0,
  topic_scores: {},
  app_view: 'input',
  study_guide_seen: false,
  theme: 'light',
  report_result: null,
  process_result: null,
  question_set: [],
  question_index: 0,
  question_attempts: {},
};

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function validMessage(value: unknown): value is ChatMessage {
  if (!isObject(value)) return false;
  const kinds: MessageKindValue[] = ['question', 'answer', 'feedback', 'hint', 'explanation'];
  const statuses: AnswerStatus[] = ['correct', 'partial', 'incorrect'];
  return typeof value.id === 'string' && value.id.length > 0 && value.id.length <= 100
    && (value.role === 'assistant' || value.role === 'user')
    && kinds.includes(value.kind as MessageKindValue)
    && typeof value.content === 'string' && value.content.length > 0 && value.content.length <= 5000
    && (value.topic_assessed === undefined || (typeof value.topic_assessed === 'string' && value.topic_assessed.length <= 240))
    && (value.answer_status === undefined || statuses.includes(value.answer_status as AnswerStatus))
    && (value.answer_score === undefined || (typeof value.answer_score === 'number' && value.answer_score >= 0 && value.answer_score <= 100));
}

function validTopicScores(value: unknown): value is Record<string, number> {
  return isObject(value) && Object.entries(value).every(([key, score]) => key.length > 0 && typeof score === 'number' && Number.isFinite(score) && score >= 0 && score <= 100);
}

function validReport(value: unknown): value is ReportResult {
  if (!isObject(value) || !Array.isArray(value.learned_topics) || !Array.isArray(value.misunderstood_topics) || !Array.isArray(value.next_practice_steps)) return false;
  const validTopics = (items: unknown[]) => items.every((item) => isObject(item) && typeof item.topic === 'string' && item.topic.length > 0 && typeof item.evidence === 'string' && item.evidence.length > 0);
  return validTopics(value.learned_topics) && validTopics(value.misunderstood_topics) && value.next_practice_steps.every((step) => typeof step === 'string' && step.length > 0);
}

function validProcessResult(value: unknown): value is ProcessResult {
  return isObject(value) && typeof value.summary === 'string' && Array.isArray(value.key_takeaways) && value.key_takeaways.every((item) => typeof item === 'string')
    && Array.isArray(value.keywords) && value.keywords.every((item) => typeof item === 'string') && typeof value.first_question === 'string'
    && (value.analogy === undefined || typeof value.analogy === 'string')
    && (value.improvement_steps === undefined || (Array.isArray(value.improvement_steps) && value.improvement_steps.every((step) => typeof step === 'string')))
    && (value.exam_focus === undefined || (Array.isArray(value.exam_focus) && value.exam_focus.every((item) => isObject(item) && typeof item.topic === 'string' && typeof item.why_it_matters === 'string' && typeof item.practice_question === 'string')));
}

function validQuestion(value: unknown): value is StudyQuestion {
  if (!isObject(value) || typeof value.id !== 'string' || !value.id ||
    (value.kind !== 'mcq' && value.kind !== 'qa') ||
    typeof value.prompt !== 'string' || !value.prompt ||
    typeof value.correct_answer !== 'string' || !value.correct_answer ||
    !Number.isInteger(value.marks) || (value.marks as number) < 1 || (value.marks as number) > 5 ||
    typeof value.explanation !== 'string' || !value.explanation) return false;
  return value.kind === 'qa' || (Array.isArray(value.options) && value.options.length === 4 &&
    value.options.every((option) => typeof option === 'string' && option.length > 0) &&
    new Set(value.options).size === 4 && value.options.includes(value.correct_answer));
}

function questionText(question: StudyQuestion, index: number, total: number): string {
  return `Question ${index + 1} of ${total} · ${question.kind === 'mcq' ? 'MCQ' : 'Q&A'} · ${question.marks} ${question.marks === 1 ? 'mark' : 'marks'}\n${question.prompt}${question.kind === 'mcq' ? `\n\n${question.options?.map((option, optionIndex) => `${String.fromCharCode(65 + optionIndex)}. ${option}`).join('\n')}` : ''}`;
}

function validSession(value: unknown): value is Session {
  if (!isObject(value)) return false;
  const views: AppView[] = ['input', 'study-guide', 'setup', 'dashboard', 'quiz', 'report'];
  if (typeof value.source_material !== 'string' || value.source_material.length > 5000
    || !Array.isArray(value.chat_history) || value.chat_history.length > 80 || !value.chat_history.every(validMessage)
    || typeof value.mastery_index !== 'number' || !Number.isFinite(value.mastery_index) || value.mastery_index < 0 || value.mastery_index > 100
    || !validTopicScores(value.topic_scores) || !views.includes(value.app_view as AppView)
    || typeof value.study_guide_seen !== 'boolean'
    || !Array.isArray(value.question_set) || value.question_set.length > 20 || !value.question_set.every(validQuestion)
    || !Number.isInteger(value.question_index) || (value.question_index as number) < 0 || (value.question_index as number) > value.question_set.length
    || !validQuestionAttempts(value.question_attempts, value.question_set)
    || (value.theme !== 'light' && value.theme !== 'dark')
    || !(value.report_result === null || validReport(value.report_result))
    || !(value.process_result === null || validProcessResult(value.process_result))) return false;
  if (value.source_material.trim().length === 0 && (value.chat_history.length > 0 || Object.keys(value.topic_scores).length > 0 || value.mastery_index !== 0 || value.report_result !== null || value.process_result !== null || value.app_view !== 'input')) return false;
  if (value.source_material.trim().length > 0 && (!value.chat_history.some((message) => message.role === 'assistant' && message.kind === 'question') || !value.process_result)) return false;
  if (value.app_view === 'report' && value.report_result === null) return false;
  if (value.app_view === 'quiz' && value.source_material.trim().length === 0) return false;
  if (value.question_set.length && value.chat_history.filter((message) => message.role === 'user').length > value.question_set.length) return false;
  return true;
}

function loadSession(): Session {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) return emptySession;
    const parsed: unknown = JSON.parse(raw);
    if (!isObject(parsed)) return emptySession;
    const questions = Array.isArray(parsed.question_set) ? parsed.question_set.map((question: unknown) =>
      isObject(question) ? { ...question, marks: question.marks ?? (question.kind === 'mcq' ? 1 : 3) } : question) : [];
    const legacyProgress = questions.every(validQuestion) && Array.isArray(parsed.chat_history) && parsed.chat_history.every(validMessage)
      ? migrateQuizProgress(questions, parsed.chat_history) : { question_attempts: {}, question_index: 0 };
    const migrated = {
      ...parsed,
      question_set: questions,
      question_index: parsed.question_index ?? legacyProgress.question_index,
      question_attempts: parsed.question_attempts ?? legacyProgress.question_attempts,
      app_view: parsed.app_view === 'quiz' && (!Array.isArray(parsed.question_set) || !parsed.question_set.length) ? 'setup' : parsed.app_view,
      study_guide_seen: typeof parsed.study_guide_seen === 'boolean'
        ? parsed.study_guide_seen
        : parsed.app_view !== 'input',
    };
    return validSession(migrated) ? migrated : emptySession;
  } catch {
    return emptySession;
  }
}

function errorDetails(error: unknown): { code: string; message: string } {
  if (error instanceof TypeError && /failed to fetch|network request failed|load failed/i.test(error.message)) {
    return { code: 'NETWORK_ERROR', message: 'We couldn’t reach the study service. Check your connection and try again. Your current study is still here.' };
  }
  if (isObject(error)) {
    const data = isObject(error.data) ? error.data : error;
    const code = typeof data.error_code === 'string' ? data.error_code : 'REQUEST_FAILED';
    const message = typeof data.message === 'string' ? data.message : 'Something went wrong. Please try again.';
    return { code, message };
  }
  return { code: 'REQUEST_FAILED', message: error instanceof Error ? error.message : 'Something went wrong. Please try again.' };
}

function makeMessage(role: ChatMessage['role'], kind: MessageKindValue, content: string, extra: Partial<ChatMessage> = {}): ChatMessage {
  return { id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`, role, kind, content, ...extra };
}

function App() {
  const [session, setSession] = useState<Session>(loadSession);
  const [sourceDraft, setSourceDraft] = useState(session.source_material);
  const [answerDraft, setAnswerDraft] = useState('');
  const [isDictating, setIsDictating] = useState(false);
  const [dictationMessage, setDictationMessage] = useState('');
  const [apiError, setApiError] = useState('');
  const [storageError, setStorageError] = useState('');
  const processMutation = useProcessSourceMaterial();
  const evaluateMutation = useEvaluateAnswer();
  const reportMutation = useCreateStudyReport();
  const questionSetMutation = useCreateQuestionSet();
  const speechRecognitionRef = useRef<SpeechRecognitionLike | null>(null);

  useEffect(() => () => {
    speechRecognitionRef.current?.abort();
  }, []);

  useEffect(() => {
    if (session.app_view !== 'quiz') speechRecognitionRef.current?.abort();
  }, [session.app_view]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
      setStorageError('');
    } catch {
      setStorageError('Browser storage is unavailable. Your current study will remain open, but changes may not persist after you leave.');
    }
    document.documentElement.classList.toggle('dark', session.theme === 'dark');
  }, [session]);

  useEffect(() => {
    setSourceDraft(session.source_material);
  }, [session.source_material]);

  const topicEntries = useMemo(() => Object.entries(session.topic_scores).sort((a, b) => b[1] - a[1]), [session.topic_scores]);
  const answerCount = Object.values(session.question_attempts).reduce((sum, attempts) => sum + attempts.length, 0) || session.chat_history.filter((message) => message.role === 'user').length;
  const currentQuestion = session.question_set[session.question_index];
  const currentAttempts = currentQuestion ? session.question_attempts[currentQuestion.id] ?? [] : [];
  const currentSolved = isSolved(currentAttempts);
  const solvedCount = session.question_set.filter((question) => isSolved(session.question_attempts[question.id])).length;
  const sessionComplete = session.question_set.length > 0 && session.question_index >= session.question_set.length && solvedCount === session.question_set.length;
  const masteryStatus: MasteryStatus = session.mastery_index >= 80 ? 'yes' : 'no';
  const studyScroll = useStudyScroll({
    view: session.app_view, questionId: currentQuestion?.id,
    attempts: currentAttempts.length, loading: evaluateMutation.isPending,
    complete: sessionComplete, error: apiError,
  });

  function updateSession(patch: Partial<Session>) {
    setSession((previous) => ({ ...previous, ...patch }));
  }

  function stopDictation() {
    speechRecognitionRef.current?.stop();
  }

  function navigate(view: AppView) {
    if (view !== 'quiz') stopDictation();
    updateSession({ app_view: view === 'quiz' ? (!session.study_guide_seen ? 'study-guide' : !session.question_set.length ? 'setup' : 'quiz') : view });
    setApiError('');
  }

  function beginQuiz() {
    updateSession({ study_guide_seen: true, app_view: 'setup' });
    setApiError('');
  }

  function generateQuestions(mcqCount: number, qaCount: number) {
    if (questionSetMutation.isPending || !session.source_material ||
      !Number.isInteger(mcqCount) || !Number.isInteger(qaCount) || mcqCount < 0 || qaCount < 0 ||
      mcqCount + qaCount < 1 || mcqCount + qaCount > 20) return;
    setApiError('');
    questionSetMutation.mutate({ data: { source_material: session.source_material, mcq_count: mcqCount, qa_count: qaCount } }, {
      onSuccess: (result) => {
        const first = result.questions[0];
        if (!first) return;
        setSession((previous) => ({
          ...previous, question_set: result.questions,
          question_index: 0, question_attempts: {},
          chat_history: [makeMessage('assistant', 'question', questionText(first, 0, result.questions.length))],
          mastery_index: 0, topic_scores: {}, report_result: null,
          study_guide_seen: true, app_view: 'quiz',
        }));
        setAnswerDraft('');
      },
      onError: (error) => setApiError(`${errorDetails(error).code}: ${errorDetails(error).message}`),
    });
  }

  function toggleDictation() {
    if (isDictating) {
      speechRecognitionRef.current?.stop();
      return;
    }

    const speechWindow = window as SpeechRecognitionWindow;
    const SpeechRecognition = speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setDictationMessage('Voice typing is not supported in this browser. Try a recent version of Chrome, Edge, or Safari.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = navigator.language || 'en-US';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.onresult = (event) => {
      let finalTranscript = '';
      let interimTranscript = '';
      for (let index = event.resultIndex; index < event.results.length; index += 1) {
        const result = event.results[index];
        if (!result) continue;
        const transcript = result[0]?.transcript ?? '';
        if (result.isFinal) finalTranscript += transcript;
        else interimTranscript += transcript;
      }
      if (finalTranscript.trim()) {
        setAnswerDraft((previous) => `${previous}${previous && !previous.endsWith(' ') ? ' ' : ''}${finalTranscript.trim()}`.slice(0, 5000));
      }
      setDictationMessage(interimTranscript.trim() ? `Listening: ${interimTranscript.trim()}` : 'Listening…');
    };
    recognition.onerror = (event) => {
      const message = event.error === 'not-allowed' || event.error === 'service-not-allowed'
        ? 'Microphone access was blocked. Allow microphone access in your browser settings and try again.'
        : event.error === 'no-speech'
          ? 'No speech was detected. Try again when you’re ready.'
          : 'Voice typing stopped. You can try again or type your answer.';
      setDictationMessage(message);
      setIsDictating(false);
      speechRecognitionRef.current = null;
    };
    recognition.onend = () => {
      setIsDictating(false);
      if (speechRecognitionRef.current === recognition) speechRecognitionRef.current = null;
      setDictationMessage((previous) => previous.startsWith('Listening') ? 'Dictation stopped.' : previous);
    };
    speechRecognitionRef.current = recognition;
    setDictationMessage('Listening…');
    setIsDictating(true);
    try {
      recognition.start();
    } catch {
      speechRecognitionRef.current = null;
      setIsDictating(false);
      setDictationMessage('Could not start voice typing. Check microphone access and try again.');
    }
  }

  function toggleTheme() {
    updateSession({ theme: session.theme === 'light' ? 'dark' : 'light' });
  }

  function startStudy(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const material = sourceDraft.trim();
    if (!material || material.length > 5000) return;
    setApiError('');
    processMutation.mutate({ data: { source_material: material } }, {
      onSuccess: (result) => {
        const question = makeMessage('assistant', 'question', result.first_question);
        setSession((previous) => ({
          ...previous,
          source_material: material,
          chat_history: [question],
          mastery_index: 0,
          topic_scores: {},
          report_result: null,
          process_result: result,
          question_set: [],
          question_index: 0, question_attempts: {},
          study_guide_seen: false,
          app_view: 'study-guide',
        }));
        setAnswerDraft('');
      },
      onError: (error) => setApiError(`${errorDetails(error).code}: ${errorDetails(error).message}`),
    });
  }

  function submitAnswer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const latestAnswer = answerDraft.trim();
    if (!latestAnswer || !session.source_material || !currentQuestion || currentSolved || evaluateMutation.isPending) return;
    stopDictation();
    setApiError('');
    const userMessage = makeMessage('user', 'answer', latestAnswer);
    const finishAnswer = (result: { feedback: ChatMessage; mastery_index: number; topic_scores: Record<string, number> }) => {
      const status = result.feedback.answer_status ?? 'incorrect';
      const safeFeedback = { ...result.feedback, content: quizFeedback(status, result.feedback.content, currentAttempts.length) };
      const attempt: QuizAttempt = {
        answer: latestAnswer, status,
        explanation: safeFeedback.content,
      };
      setSession((previous) => {
        if (previous.question_index !== session.question_index || previous.question_set[previous.question_index]?.id !== currentQuestion.id ||
          (previous.question_attempts[currentQuestion.id]?.length ?? 0) !== currentAttempts.length) return previous;
        return {
          ...previous,
          question_attempts: { ...previous.question_attempts, [currentQuestion.id]: [...currentAttempts, attempt] },
          chat_history: currentAttempts.length ? previous.chat_history : [...previous.chat_history, userMessage, safeFeedback],
          mastery_index: result.mastery_index, topic_scores: result.topic_scores, report_result: null,
        };
      });
      setAnswerDraft('');
    };
    if (currentQuestion.kind === 'mcq') {
      if (!currentQuestion.options?.includes(latestAnswer)) return;
      const correct = latestAnswer === currentQuestion.correct_answer;
      const score = correct ? 100 : 0;
      const topic = currentQuestion.prompt.slice(0, 240);
      finishAnswer({
        feedback: makeMessage('assistant', 'feedback',
          correct ? `Well done—you got it right! ${currentQuestion.explanation}` :
            quizFeedback('incorrect', '', currentAttempts.length),
          { answer_status: correct ? 'correct' : 'incorrect', answer_score: score, topic_assessed: topic }),
        mastery_index: Math.round(session.mastery_index * 0.7 + score * 0.3),
        topic_scores: { ...session.topic_scores, [topic]: Math.round((session.topic_scores[topic] ?? 0) * 0.7 + score * 0.3) },
      });
      return;
    }
    evaluateMutation.mutate({
      data: {
        source_material: session.source_material,
        chat_history: [makeMessage('assistant', 'question', currentQuestion.prompt)],
        latest_answer: latestAnswer,
        mastery_index: session.mastery_index,
        topic_scores: session.topic_scores,
      },
    }, {
      onSuccess: finishAnswer,
      onError: (error) => setApiError(`${errorDetails(error).code}: ${errorDetails(error).message}`),
    });
  }

  function nextQuestion() {
    if (!currentQuestion || !currentSolved || evaluateMutation.isPending) return;
    stopDictation();
    setSession((previous) => {
      if (previous.question_index !== session.question_index || previous.question_set[previous.question_index]?.id !== currentQuestion.id ||
        !isSolved(previous.question_attempts[currentQuestion.id])) return previous;
      const nextIndex = previous.question_index + 1;
      const next = previous.question_set[nextIndex];
      const last = previous.chat_history.at(-1);
      const practice = currentAttempts.length > 1 ? `\n\nAfter practice: ${currentAttempts.at(-1)?.explanation}` : '';
      return {
        ...previous, question_index: nextIndex,
        chat_history: last ? [...previous.chat_history.slice(0, -1), {
          ...last, content: `${last.content}${practice}${next ? `\n\n${questionText(next, nextIndex, previous.question_set.length)}` : ''}`.slice(0, 5000),
        }] : previous.chat_history,
      };
    });
    setAnswerDraft('');
    setApiError('');
  }

  function refreshGuide() {
    if (processMutation.isPending || !session.source_material) return;
    setApiError('');
    const source = session.source_material;
    processMutation.mutate({ data: { source_material: source } }, {
      onSuccess: (result) => setSession((previous) => previous.source_material === source ? { ...previous, process_result: result } : previous),
      onError: (error) => setApiError(`${errorDetails(error).code}: ${errorDetails(error).message}`),
    });
  }

  function createReport() {
    setApiError('');
    reportMutation.mutate({ data: { chat_history: session.chat_history } }, {
      onSuccess: (result) => {
        setSession((previous) => ({ ...previous, report_result: result, app_view: 'report' }));
      },
      onError: (error) => setApiError(`${errorDetails(error).code}: ${errorDetails(error).message}`),
    });
  }

  function resetStudy() {
    const nextSession: Session = { ...emptySession, theme: session.theme };
    setSession(nextSession);
    setSourceDraft('');
    setAnswerDraft('');
    setApiError('');
  }

  const currentView = session.app_view;
  const requestStatus: RequestStatus = processMutation.isPending || evaluateMutation.isPending || reportMutation.isPending || questionSetMutation.isPending ? 'loading' : apiError ? 'error' : 'idle';
  const navItems: { view: AppView; label: string; icon: typeof PanelTop }[] = [
    { view: 'study-guide', label: 'Study guide', icon: BookOpen },
    { view: 'dashboard', label: 'Overview', icon: PanelTop },
    { view: 'quiz', label: 'Study session', icon: CircleHelp },
    { view: 'report', label: 'Study report', icon: FileText },
  ];

  return (
    <div className="app-shell">
      <header className="topbar sticky top-0 z-20">
        <div className="page-wrap flex min-h-[72px] items-center justify-between gap-4">
          <button className="flex items-center gap-3 text-left" onClick={() => navigate('input')} data-testid="link-home" aria-label="Go to source material input">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary text-primary-foreground"><BookOpen size={19} /></span>
            <span>
              <span className="block text-[15px] font-bold tracking-tight">learnr</span>
              <span className="block text-[11px] text-muted-foreground">Study from your own notes</span>
            </span>
          </button>
          <nav aria-label="Study navigation" className="hidden items-center gap-1 md:flex">
            {navItems.map(({ view, label, icon: Icon }) => (
              <button key={view} className={`nav-link flex items-center gap-2 rounded-lg px-3 py-2 text-[13px] font-semibold ${currentView === view ? 'active' : ''}`}
                onClick={() => navigate(view)} disabled={!session.source_material || (view === 'quiz' && !session.study_guide_seen) || (view === 'report' && !session.report_result)} data-testid={`nav-${view}`}>
                <Icon size={15} />{label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            {session.source_material && <button className="quiet-button hidden rounded-lg px-3 py-2 text-xs font-semibold sm:inline-flex" onClick={resetStudy} data-testid="button-new-study">New study</button>}
            <button className="theme-switch quiet-button inline-flex h-10 items-center gap-2 rounded-xl px-2.5" onClick={toggleTheme} role="switch" aria-checked={session.theme === 'dark'} aria-label={`Switch to ${session.theme === 'light' ? 'dark' : 'light'} mode`} data-testid="button-theme-toggle">
              {session.theme === 'light' ? <Moon size={15} /> : <Sun size={15} />}
              <span className="text-xs font-semibold">{session.theme === 'light' ? 'Light' : 'Dark'}</span>
              <span aria-hidden="true" className={`theme-switch-track ${session.theme === 'dark' ? 'is-dark' : ''}`}><span className="theme-switch-thumb" /></span>
            </button>
          </div>
        </div>
        <nav aria-label="Study navigation" className="page-wrap flex gap-1 overflow-x-auto pb-2 md:hidden">
          {navItems.map(({ view, label }) => (
            <button key={view} className={`nav-link whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-semibold ${currentView === view ? 'active' : ''}`}
                onClick={() => navigate(view)} disabled={!session.source_material || (view === 'quiz' && !session.study_guide_seen) || (view === 'report' && !session.report_result)} data-testid={`mobile-nav-${view}`}>{label}</button>
          ))}
          {session.source_material && <button className="nav-link whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-semibold" onClick={resetStudy} data-testid="mobile-button-new-study">New study</button>}
        </nav>
      </header>

      <main ref={studyScroll.page} tabIndex={-1} className="page-wrap scroll-mt-32 py-6 outline-none sm:py-10 md:scroll-mt-24" data-request-status={requestStatus}>
        {storageError && <div role="status" className="mb-6 rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-sm text-muted-foreground" data-testid="status-storage-warning">{storageError}</div>}
        {apiError && <div ref={studyScroll.errorBanner} tabIndex={-1} role="alert" className="mb-6 flex scroll-mt-32 items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm outline-none md:scroll-mt-24" data-testid="status-api-error">
          <AlertCircle className="mt-0.5 shrink-0 text-destructive" size={17} />
          <div><p className="font-semibold text-destructive">We couldn’t complete that request</p><p className="mt-1 text-foreground">{apiError}</p>
            {apiError.includes('AI_PROVIDER_NOT_CONFIGURED') && <p className="mt-2 text-muted-foreground">Please ask the app owner to check the study service configuration. Your study content is still saved in this browser.</p>}
          </div>
          <button className="ml-auto rounded p-1 text-muted-foreground hover:text-foreground" onClick={() => setApiError('')} aria-label="Dismiss error" data-testid="button-dismiss-error">×</button>
        </div>}

        {currentView === 'input' && <section className="enter mx-auto grid max-w-5xl gap-10 lg:grid-cols-[1.03fr_.97fr] lg:items-center">
          <div className="py-4">
            <p className="eyebrow flex items-center gap-2"><span className="h-px w-7 bg-primary" />Study companion</p>
            <h1 className="serif mt-5 max-w-xl text-4xl leading-[1.12] tracking-[-.03em] sm:text-5xl">Understand your notes,<br /><span className="text-primary">one step at a time.</span></h1>
            <p className="mt-6 max-w-lg text-base leading-7 text-muted-foreground">Paste your notes. learnr explains them simply, then asks questions drawn only from your text.</p>
            <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-2"><CheckCircle2 size={16} className="text-primary" />Questions come only from your notes</span>
              <span className="flex items-center gap-2"><CheckCircle2 size={16} className="text-primary" />Retry until it makes sense</span>
            </div>
          </div>
          <form onSubmit={startStudy} className="surface rounded-2xl p-5 sm:p-7" data-testid="form-source-material">
            <div className="mb-5 flex items-start justify-between gap-4">
              <div><p className="eyebrow">Your material</p><h2 className="serif mt-2 text-2xl">What are you studying?</h2></div>
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-secondary text-primary"><FileText size={18} /></span>
            </div>
            <SourceImporter hasDraft={Boolean(sourceDraft.trim())} disabled={processMutation.isPending} onUseText={(text, mode) => setSourceDraft((previous) => mode === 'append' && previous.trim() ? `${previous}\n\n${text}` : text)} />
            <label htmlFor="source-material" className="mb-2 block text-sm font-semibold">Paste your notes</label>
            <textarea id="source-material" value={sourceDraft} onChange={(event) => setSourceDraft(event.target.value)}
              placeholder="Paste a passage, lecture notes, or a topic…" rows={8}
              className="w-full resize-y rounded-xl border border-input bg-background px-4 py-3 text-sm leading-6 outline-none transition focus:border-primary"
              aria-describedby="source-counter source-help" data-testid="input-source-material" />
            <div className="mt-2 flex items-center justify-between gap-3 text-xs text-muted-foreground"><span id="source-help">Your text is sent to an AI service to build the guide.</span><span id="source-counter" className={sourceDraft.length > 5000 ? 'shrink-0 text-destructive' : 'shrink-0'} data-testid="text-source-character-count">{sourceDraft.length.toLocaleString()} / 5,000</span></div>
            {sourceDraft.length > 5000 && <p role="alert" className="mt-2 text-xs text-destructive">Please shorten the draft to 5,000 characters before continuing. Your imported text has not been truncated.</p>}
            <button type="submit" disabled={!sourceDraft.trim() || sourceDraft.length > 5000 || processMutation.isPending} className="primary-button mt-6 flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3.5 text-sm font-bold" data-testid="button-process-source">
              {processMutation.isPending ? <><span className="h-4 w-4 animate-pulse rounded-full bg-current/50" />Preparing your guide…</> : <>Create study guide <ArrowRight size={17} /></>}
            </button>
            <p className="mt-3 text-center text-xs text-muted-foreground">Up to 5,000 characters</p>
          </form>
        </section>}

        {currentView === 'study-guide' && session.process_result && <section className="enter mx-auto max-w-4xl" data-testid="study-guide">
          <div className="mb-8">
            <p className="eyebrow">Before you begin</p>
            <h1 className="serif mt-2 text-4xl tracking-tight">Study guide</h1>
            <p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Read the summary, then the key points. You can return here at any time.</p>
            <button onClick={refreshGuide} disabled={processMutation.isPending} className="quiet-button mt-4 inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold" data-testid="button-refresh-guide"><RefreshCw size={14} className={processMutation.isPending ? 'animate-spin' : ''} />{processMutation.isPending ? 'Updating…' : session.process_result.analogy ? 'Refresh study guide' : 'Generate the easier guide'}</button>
            {!session.process_result.analogy && <p className="mt-2 text-xs text-muted-foreground">This is an older saved guide. Generate the easier version to add an analogy and revision advice. Your progress is kept.</p>}
          </div>
          <article className="surface rounded-2xl p-6 sm:p-7" data-testid="guide-summary">
            <p className="eyebrow">Summary</p>
            <h2 className="serif mt-2 text-2xl">In simple terms</h2>
            <p className="mt-4 whitespace-pre-wrap text-base leading-8">{session.process_result.summary}</p>
          </article>
          {session.process_result.analogy && <article className="mt-5 rounded-2xl border border-primary/15 bg-primary/5 p-6 sm:p-7" data-testid="guide-analogy">
            <p className="eyebrow">Analogy</p>
            <h2 className="serif mt-2 text-2xl">A way to picture it</h2>
            <p className="mt-4 whitespace-pre-wrap text-sm leading-7">{session.process_result.analogy}</p>
            <p className="mt-3 text-xs text-muted-foreground">A memory aid only. Questions still use just your notes.</p>
          </article>}
          <article className="surface mt-5 rounded-2xl p-6 sm:p-7" data-testid="guide-key-points">
            <p className="eyebrow">Key points</p>
            <h2 className="serif mt-2 text-2xl">What to remember</h2>
            <ul className="mt-5 space-y-3">
              {session.process_result.key_takeaways.map((point, index) => <li key={`${index}-${point}`} className="flex gap-3 text-sm leading-6" data-testid={`guide-point-${index}`}>
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-secondary text-xs font-bold text-primary">{index + 1}</span><span>{point}</span>
              </li>)}
            </ul>
          </article>
          <article className="surface mt-5 rounded-2xl p-6 sm:p-7" data-testid="guide-keywords">
            <p className="eyebrow">Keywords</p>
            <h2 className="serif mt-2 text-2xl">Terms</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {session.process_result.keywords.map((word, index) => <span key={`${word}-${index}`} className="rounded-full bg-secondary px-3 py-1.5 text-xs font-medium text-secondary-foreground" data-testid={`guide-keyword-${index}`}>{word}</span>)}
            </div>
          </article>
          {session.process_result.improvement_steps?.length ? <article className="surface mt-5 rounded-2xl p-6 sm:p-7" data-testid="guide-improvement">
            <p className="eyebrow">Revision</p>
            <h2 className="serif mt-2 text-2xl">Revision checklist</h2>
            <ol className="mt-4 space-y-3">{session.process_result.improvement_steps.map((step, index) => <li key={`${index}-${step}`} className="flex gap-3 text-sm leading-6"><span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-secondary text-xs font-bold text-primary">{index + 1}</span><span>{step}</span></li>)}</ol>
          </article> : null}
          {session.process_result.exam_focus?.length ? <article className="surface mt-5 rounded-2xl p-6 sm:p-7" data-testid="guide-exam-focus">
            <p className="eyebrow">Practice priorities</p>
            <h2 className="serif mt-2 text-2xl">What to revise</h2>
            <p className="mt-3 text-xs leading-6 text-muted-foreground">Taken from your notes, not a syllabus. Not a prediction of any exam.</p>
            <div className="mt-5 space-y-4">{session.process_result.exam_focus.map((focus, index) => <section key={`${index}-${focus.topic}`} className="rounded-xl border border-border p-4">
              <h3 className="text-sm font-bold">{focus.topic}</h3>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">{focus.why_it_matters}</p>
              <p className="mt-3 text-sm leading-6"><span className="font-semibold text-primary">Practise answering: </span>{focus.practice_question}</p>
            </section>)}</div>
          </article> : null}
          <div className="mt-5"><DoubtPanel key={`guide-${session.source_material}`} sourceMaterial={session.source_material} /></div>
          <div className="mt-7 flex flex-wrap items-center justify-between gap-4">
            <p className="text-xs text-muted-foreground">You can reopen this guide during practice.</p>
            <button onClick={beginQuiz} className="primary-button inline-flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-bold" data-testid="button-begin-quiz">Choose my questions <ArrowRight size={16} /></button>
          </div>
        </section>}

        {currentView === 'setup' && <section className="mx-auto max-w-4xl">
          <button onClick={() => navigate('study-guide')} disabled={questionSetMutation.isPending} className="quiet-button mb-5 inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold"><ArrowLeft size={14} />Back to study guide</button>
          <SessionSetup onStart={generateQuestions} pending={questionSetMutation.isPending} hasExistingAnswers={answerCount > 0} />
        </section>}

        {currentView === 'dashboard' && <section className="enter">
          <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
            <div><p className="eyebrow">Overview</p><h1 className="serif mt-2 text-4xl tracking-tight">Study overview</h1><p className="mt-2 text-sm text-muted-foreground">What is clicking and what needs another look.</p></div>
            <button onClick={() => navigate(session.study_guide_seen ? 'quiz' : 'study-guide')} className="primary-button inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-bold" data-testid="button-continue-study">{session.study_guide_seen ? 'Continue studying' : 'Review study guide'} <ArrowRight size={16} /></button>
          </div>
          <div className="grid gap-4 md:grid-cols-[1.1fr_.9fr]">
            <article className="surface rounded-2xl p-6 sm:p-7" data-testid="card-mastery">
              <div className="flex items-start justify-between gap-3"><div><p className="eyebrow">Overall mastery</p><p className="serif mt-3 text-2xl">{masteryStatus === 'yes' ? 'Strong' : 'Building'}</p></div>
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-secondary text-primary"><TrendingUp size={20} /></span></div>
              <div className="meter-track mt-6"><div className="meter-fill" style={{ width: `${session.mastery_index}%` }} /></div>
              <div className="mt-3 flex justify-between text-xs"><span className="font-semibold text-primary" data-testid="status-mastery">{masteryStatus === 'yes' ? 'Strong' : 'Building'} understanding</span><span className="text-muted-foreground">Based on your answers</span></div>
              <div className="mt-7 grid grid-cols-2 gap-3 border-t border-border pt-5">
                <div><p className="text-xs text-muted-foreground">Answers explored</p><p className="mt-1 text-2xl font-semibold" data-testid="text-answer-count">{answerCount}</p></div>
                <div><p className="text-xs text-muted-foreground">Topics assessed</p><p className="mt-1 text-2xl font-semibold" data-testid="text-topic-count">{topicEntries.length}</p></div>
              </div>
            </article>
            <article className="surface rounded-2xl p-6 sm:p-7" data-testid="card-material-summary">
              <p className="eyebrow">The big idea</p><h2 className="serif mt-2 text-xl">A quick recap</h2>
              <p className="mt-4 whitespace-pre-wrap text-sm leading-6 text-muted-foreground" data-testid="text-summary-preview">{session.process_result?.summary}</p>
              {session.process_result?.keywords.length ? <div className="mt-5 flex flex-wrap gap-2">{session.process_result.keywords.slice(0, 6).map((word, index) => <span key={`${word}-${index}`} className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground" data-testid={`tag-keyword-${index}`}>{word}</span>)}</div> : null}
            </article>
          </div>
          <article className="surface mt-5 rounded-2xl p-6 sm:p-7" data-testid="card-topic-mastery">
            <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="eyebrow">Topic-by-topic</p><h2 className="serif mt-2 text-2xl">Understanding by topic</h2></div><span className="text-xs text-muted-foreground">Updates as you answer</span></div>
            {topicEntries.length ? <div className="mt-6 grid gap-x-10 gap-y-5 sm:grid-cols-2">{topicEntries.map(([topic, score], index) => <div key={topic} data-testid={`topic-score-${index}`}>
              <div className="mb-2 flex justify-between gap-4 text-sm"><span className="font-medium">{topic}</span></div><div className="meter-track"><div className="meter-fill" style={{ width: `${score}%` }} /></div>
            </div>)}</div> : <div className="mt-6 rounded-xl border border-dashed border-border bg-muted/30 px-5 py-8 text-center"><Target className="mx-auto text-primary" size={23} /><p className="mt-3 text-sm font-semibold">No topic scores yet</p><p className="mt-1 text-xs text-muted-foreground">They appear as you answer questions.</p></div>}
          </article>
          {session.process_result && <article className="mt-5 rounded-2xl bg-primary px-6 py-6 text-primary-foreground sm:flex sm:items-center sm:justify-between sm:gap-8 sm:px-8">
            <div><p className="text-xs font-bold uppercase tracking-[.14em] opacity-75">Your material in brief</p><p className="serif mt-2 max-w-2xl text-lg leading-7">{session.process_result.summary}</p></div>
            <button onClick={() => navigate('quiz')} className="mt-5 inline-flex shrink-0 items-center gap-2 rounded-lg bg-background px-4 py-2.5 text-sm font-bold text-foreground sm:mt-0" data-testid="button-open-questions">Open questions <ArrowRight size={15} /></button>
          </article>}
        </section>}

        {currentView === 'quiz' && <section className="enter">
          <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div><p className="eyebrow">Practice · {solvedCount} of {session.question_set.length} understood</p><h1 className="serif mt-2 text-4xl tracking-tight">{sessionComplete ? 'Your quiz results' : 'Practice questions'}</h1><p className="mt-2 text-sm text-muted-foreground">Retry until each answer is right, then continue when ready.</p></div>
            <div className="flex gap-2"><button onClick={() => navigate('dashboard')} className="quiet-button inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold" data-testid="button-open-dashboard"><PanelTop size={15} />Overview</button>
              <button onClick={createReport} disabled={!session.chat_history.some((message) => message.role === 'user') || reportMutation.isPending} className="quiet-button inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold" data-testid="button-create-report">{reportMutation.isPending ? <span className="h-3 w-3 animate-pulse rounded-full bg-primary" /> : <FileText size={15} />}Create report</button></div>
          </div>
          <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_310px]">
            <section className="surface flex min-h-[610px] flex-col overflow-hidden rounded-2xl" aria-label="Question and answer conversation">
              <div className="flex items-center justify-between border-b border-border px-5 py-4">
                <div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-full bg-primary/10 text-primary"><CircleHelp size={18} /></span><div><p className="text-sm font-bold">Your examiner</p><p className="text-xs text-muted-foreground">Based on your notes</p></div></div>
                <span className="rounded-full bg-secondary px-3 py-1 text-[11px] font-semibold text-secondary-foreground">{masteryStatus === 'yes' ? 'Strong' : 'Building'}</span>
              </div>
              <div className="chat-scroll flex-1 space-y-5 overflow-y-auto p-4 sm:p-6" data-testid="list-chat-history" aria-live="polite">
                {!sessionComplete && currentQuestion && <article ref={studyScroll.question} tabIndex={-1} aria-label="Current quiz question" className="scroll-mt-32 rounded-2xl bg-muted/75 px-4 py-4 outline-none md:scroll-mt-24" data-testid="active-question">
                  <p className="whitespace-pre-wrap text-sm leading-7">{questionText(currentQuestion, session.question_index, session.question_set.length)}</p>
                  <p className="mt-4 text-xs leading-5 text-muted-foreground">Scoring uses your first answer: correct earns {currentQuestion.marks}, partly correct {Math.floor(currentQuestion.marks / 2)}, incorrect 0. Retries do not change marks.</p>
                </article>}
                {!sessionComplete && currentQuestion && <p className="rounded-xl border border-primary/15 bg-primary/5 px-4 py-3 text-sm leading-6 text-muted-foreground" data-testid="quiz-motivation">
                  {quizMotivation(session.question_index, session.question_set.length, currentSolved, currentAttempts.length)}
                </p>}
                {!sessionComplete && currentAttempts.map((attempt, index) => <article key={`${currentQuestion?.id}-${index}`} className="space-y-3" data-testid={`attempt-${index}`}>
                  <div className="ml-auto max-w-[90%] rounded-2xl rounded-br-md bg-primary px-4 py-3 text-primary-foreground">
                    <p className="mb-1 text-xs font-bold">Your answer · attempt {index + 1}</p>
                    <p className="whitespace-pre-wrap break-words text-sm leading-6">{attempt.answer}</p>
                  </div>
                  <div ref={index === currentAttempts.length - 1 ? studyScroll.feedback : undefined} tabIndex={-1} aria-label="Answer feedback" className="max-w-[95%] scroll-mt-32 rounded-2xl rounded-bl-md border border-primary/20 bg-primary/5 px-4 py-3 outline-none md:scroll-mt-24" data-testid={`feedback-${index}`}>
                    <p className="mb-2 text-sm font-bold text-primary">{attempt.status === 'correct' ? 'Correct — well done!' : attempt.status === 'partial' ? 'Partly correct — let’s build on that' : 'Not correct yet — let’s work through it'}</p>
                    <p className="whitespace-pre-wrap break-words text-sm leading-6">{quizFeedback(attempt.status, attempt.explanation, index)}</p>
                  </div>
                </article>)}
                {sessionComplete && <QuizResults questions={session.question_set} attempts={session.question_attempts} />}
                {evaluateMutation.isPending && <div ref={studyScroll.pending} className="flex scroll-mt-32 justify-start md:scroll-mt-24" role="status" aria-label="Checking your answer" data-testid="status-evaluating"><div className="w-40 space-y-2 rounded-2xl bg-muted p-4"><div className="h-2 w-24 animate-pulse rounded bg-muted-foreground/20" /><div className="h-2 w-32 animate-pulse rounded bg-muted-foreground/20" /></div></div>}
              </div>
              {sessionComplete ? <div className="border-t border-border p-5" data-testid="session-complete">
                <p className="font-semibold">You’ve finished all {session.question_set.length} questions.</p>
                <p className="mt-2 text-sm text-muted-foreground">Your score and answer review are above.</p>
                <div className="mt-4 flex flex-wrap gap-3">
                  <button onClick={createReport} disabled={reportMutation.isPending} className="primary-button rounded-lg px-4 py-2 text-sm font-semibold">Create study report</button>
                  <button onClick={() => navigate('setup')} className="quiet-button rounded-lg px-4 py-2 text-sm font-semibold">Choose another question set</button>
                </div>
              </div> : currentSolved ? <div className="border-t border-border p-5" data-testid="question-solved">
                <p className="text-sm leading-6">Well done. Read the explanation, then continue when you’re ready.</p>
                <button onClick={nextQuestion} className="primary-button mt-4 inline-flex items-center gap-2 rounded-lg px-5 py-3 text-sm font-bold" data-testid="button-next-question">{session.question_index === session.question_set.length - 1 ? 'See quiz results' : 'Next Question'}<ArrowRight size={16} /></button>
              </div> : <form onSubmit={submitAnswer} className="border-t border-border bg-background/60 p-4 sm:p-5" data-testid="form-answer">
                {currentQuestion?.kind === 'mcq' ? <fieldset>
                  <legend className="mb-3 text-sm font-semibold">Choose one answer</legend>
                  <div className="grid gap-2">
                    {currentQuestion.options?.map((option, index) => <label key={option} className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3 text-sm ${answerDraft === option ? 'border-primary bg-primary/5' : 'border-border'}`}>
                      <input type="radio" name="mcq-answer" value={option} checked={answerDraft === option} onChange={() => setAnswerDraft(option)} className="mt-1 accent-primary" data-testid={`option-${index}`} />
                      <span><span className="mr-2 font-semibold">{String.fromCharCode(65 + index)}.</span>{option}</span>
                    </label>)}
                  </div>
                  <button type="submit" disabled={!answerDraft || evaluateMutation.isPending} className="primary-button mt-4 rounded-lg px-4 py-2 text-sm font-semibold" data-testid="button-submit-mcq">{currentAttempts.length ? 'Try again' : 'Submit answer'}</button>
                </fieldset> : <>
                <label htmlFor="answer-input" className="mb-2 block text-xs font-semibold text-muted-foreground">Your answer</label>
                <div className="flex items-end gap-2">
                  <textarea id="answer-input" value={answerDraft} onChange={(event) => setAnswerDraft(event.target.value.slice(0, 5000))} rows={2} maxLength={5000}
                    placeholder="Explain in your own words…" className="min-h-[56px] flex-1 resize-y rounded-xl border border-input bg-card px-4 py-3 text-sm leading-6 outline-none focus:border-primary"
                    data-testid="input-answer" aria-label="Your answer" />
                  <button type="button" onClick={toggleDictation} disabled={evaluateMutation.isPending} aria-pressed={isDictating}
                    aria-label={isDictating ? 'Stop dictating answer' : 'Dictate answer'} title={isDictating ? 'Stop dictating' : 'Dictate answer'}
                    className={`quiet-button grid h-12 w-12 shrink-0 place-items-center rounded-xl ${isDictating ? 'border-primary text-primary' : ''}`}
                    data-testid="button-dictate-answer">
                    {isDictating ? <MicOff size={17} /> : <Mic size={17} />}
                  </button>
                  <button type="submit" disabled={!answerDraft.trim() || evaluateMutation.isPending} className="primary-button grid h-12 w-12 shrink-0 place-items-center rounded-xl" aria-label="Submit answer" data-testid="button-submit-answer"><Send size={17} /></button>
                </div>
                {dictationMessage && <p role="status" className={`mt-2 text-xs ${isDictating ? 'text-primary' : 'text-muted-foreground'}`} data-testid="status-dictation">{dictationMessage}</p>}
                <div className="mt-2 flex justify-between gap-3 text-[11px] text-muted-foreground"><span>{currentAttempts.length ? 'Try again when ready.' : 'First answer sets the marks.'}</span><span>{answerDraft.length}/5,000</span></div>
                </>}
              </form>}
            </section>
            <aside className="space-y-4">
              <DoubtPanel key={session.source_material} sourceMaterial={session.source_material} />
              <article className="surface rounded-2xl p-5" data-testid="card-study-support">
                <div className="flex items-center gap-2"><Lightbulb size={17} className="text-primary" /><p className="text-sm font-bold">Need a refresher?</p></div>
                <p className="mt-2 text-xs leading-5 text-muted-foreground">Reopen the summary and checklist. Progress is kept.</p>
                <button onClick={() => navigate('study-guide')} className="quiet-button mt-4 inline-flex items-center gap-2 rounded-lg px-3 py-2.5 text-xs font-semibold" data-testid="button-review-guide"><BookOpen size={14} />Review study guide</button>
              </article>
              <article className="surface rounded-2xl p-5" data-testid="card-session-progress">
                <p className="eyebrow">Progress</p><div className="mt-3 flex items-baseline justify-between"><span className="text-sm font-semibold">Overall mastery</span></div><div className="meter-track mt-2"><div className="meter-fill" style={{ width: `${session.mastery_index}%` }} /></div>
                <p className="mt-3 text-xs leading-5 text-muted-foreground">{topicEntries.length ? `${topicEntries.length} topic${topicEntries.length === 1 ? '' : 's'} assessed from your responses.` : 'Topic insights appear as you answer questions.'}</p>
                <button onClick={() => navigate('dashboard')} className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-primary" data-testid="link-progress-dashboard">See topic details <ArrowRight size={13} /></button>
              </article>
              <article className="rounded-2xl border border-primary/15 bg-primary/5 p-5">
                <p className="text-xs font-bold text-primary">Tip</p><p className="mt-2 text-sm leading-6 text-muted-foreground">Try explaining the idea as if teaching a friend.</p>
              </article>
            </aside>
          </div>
        </section>}

        {currentView === 'report' && <section className="enter mx-auto max-w-4xl">
          <div className="mb-7 flex flex-wrap items-end justify-between gap-4"><div><p className="eyebrow">Report</p><h1 className="serif mt-2 text-4xl tracking-tight">Study report</h1><p className="mt-2 text-sm text-muted-foreground">Based on your answers, not only the score.</p></div>
            <button onClick={() => navigate('quiz')} className="quiet-button inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold" data-testid="button-back-to-study"><ArrowLeft size={14} />Back to session</button>
          </div>
          {session.report_result ? <>
            <div className="surface rounded-2xl p-6 sm:p-8" data-testid="report-summary">
              <div className="flex items-start justify-between gap-4"><div><p className="eyebrow">Summary</p><h2 className="serif mt-2 text-2xl">What you covered</h2></div><span className="grid h-11 w-11 place-items-center rounded-xl bg-secondary text-primary"><Check size={21} /></span></div>
              <p className="mt-4 text-sm leading-6 text-muted-foreground">Based on {answerCount} learner {answerCount === 1 ? 'response' : 'responses'} and {session.chat_history.filter((message) => message.role === 'assistant').length} examiner prompts.</p>
            </div>
            <div className="mt-5 grid gap-5 md:grid-cols-2">
              <ReportTopics title="Understood" description="Shown by your answers" items={session.report_result.learned_topics} kind="learned" />
              <ReportTopics title="Review again" description="Topics to reinforce, including questions that needed retries" items={buildReviewTopics(session.report_result.misunderstood_topics, session.question_set, session.question_attempts)} kind="review" />
            </div>
            <article className="surface mt-5 rounded-2xl p-6 sm:p-7" data-testid="card-next-practice">
              <p className="eyebrow">Practice</p><h2 className="serif mt-2 text-2xl">Next steps</h2>
              {session.report_result.next_practice_steps.length ? <ol className="mt-5 space-y-3">{session.report_result.next_practice_steps.map((step, index) => <li key={`${index}-${step}`} className="flex gap-3 text-sm leading-6" data-testid={`practice-step-${index}`}><span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-secondary text-xs font-bold text-primary">{index + 1}</span><span>{step}</span></li>)}</ol> : <p className="mt-4 text-sm text-muted-foreground">No practice steps were included in this report.</p>}
            </article>
            <div className="mt-5 flex flex-wrap justify-between gap-3"><button onClick={createReport} disabled={reportMutation.isPending} className="quiet-button inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold" data-testid="button-refresh-report"><RefreshCw size={15} />Refresh report</button><button onClick={() => navigate('dashboard')} className="primary-button inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-bold" data-testid="button-report-dashboard">View dashboard <ArrowRight size={15} /></button></div>
          </> : <div className="surface rounded-2xl px-6 py-14 text-center" data-testid="empty-report"><FileText className="mx-auto text-primary" size={28} /><h2 className="serif mt-4 text-2xl">No report yet</h2><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-muted-foreground">Answer at least one question, then create a report.</p><button onClick={() => navigate('quiz')} className="primary-button mt-6 inline-flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-bold" data-testid="button-start-report-session">Return to your session <ArrowRight size={16} /></button></div>}
        </section>}
      </main>

      <footer className="page-wrap mt-10 border-t border-border py-6 text-xs text-muted-foreground sm:flex sm:items-center sm:justify-between">
        <p>learnr</p><p className="mt-2 sm:mt-0">Progress is saved in this browser only.</p>
      </footer>
    </div>
  );
}

function ReportTopics({ title, description, items, kind }: { title: string; description: string; items: ReportResult['learned_topics']; kind: 'learned' | 'review' }) {
  return <article className="surface rounded-2xl p-6" data-testid={`card-report-${kind}`}>
    <div className="flex items-start gap-3"><span className="grid h-9 w-9 place-items-center rounded-lg bg-secondary text-primary">{kind === 'learned' ? <CheckCircle2 size={17} /> : <RefreshCw size={16} />}</span><div><h2 className="serif text-xl">{title}</h2><p className="mt-1 text-xs text-muted-foreground">{description}</p></div></div>
    {items.length ? <ul className="mt-5 space-y-4">{items.map((item, index) => <li key={`${item.topic}-${index}`} className="border-t border-border pt-4" data-testid={`report-topic-${kind}-${index}`}><p className="text-sm font-bold">{item.topic}</p><p className="mt-1.5 whitespace-pre-line text-sm leading-6 text-muted-foreground">{item.evidence}</p></li>)}</ul> : <div className="mt-5 rounded-lg bg-muted/45 p-4 text-sm leading-6 text-muted-foreground" data-testid={`empty-report-${kind}`}>{kind === 'review' ? 'No extra review topics were flagged from your recorded answers. Revisit the key points to keep them fresh.' : 'No topics were listed in this section of the report.'}</div>}
  </article>;
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={App} /><Route path="/dashboard" component={App} /><Route path="/quiz" component={App} /><Route path="/report" component={App} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Root() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default Root;
