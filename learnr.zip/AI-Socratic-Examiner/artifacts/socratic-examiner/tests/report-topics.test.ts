import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { StudyQuestion } from '@workspace/api-client-react';
import { buildReviewTopics } from '../src/lib/report-topics';
import type { QuizAttempt } from '../src/lib/quiz-progress';

const question: StudyQuestion = {
  id: 'q1', kind: 'qa', marks: 3,
  prompt: 'Which two energy carriers are used?',
  correct_answer: 'ATP and NADPH',
  explanation: 'The notes name both ATP and NADPH.',
};
const answer = (status: QuizAttempt['status']): QuizAttempt => ({
  status, answer: status === 'correct' ? 'ATP and NADPH' : 'ATP',
  explanation: 'Both energy carriers are needed.',
});

test('empty AI review includes incorrect first answers, even after a correct retry', () => {
  const topics = buildReviewTopics([], [question], { q1: [answer('incorrect'), answer('correct')] });
  assert.equal(topics.length, 1);
  assert.equal(topics[0].topic, question.prompt);
  assert.match(topics[0].evidence, /Your first answer \(incorrect\): ATP/);
  assert.ok(topics[0].evidence.includes(`Expected answer: ${question.correct_answer}`));
  assert.ok(topics[0].evidence.includes(question.explanation));
  assert.match(topics[0].evidence, /right after practice/);
});

test('partly correct answers receive an actionable review', () => {
  const topics = buildReviewTopics([], [question], { q1: [answer('partial')] });
  assert.match(topics[0].evidence, /partly correct/);
  assert.match(topics[0].evidence, /try answering again/);
});

test('correct first answers and unanswered questions do not invent mistakes', () => {
  assert.deepEqual(buildReviewTopics([], [question], { q1: [answer('correct')] }), []);
  assert.deepEqual(buildReviewTopics([], [question], {}), []);
});

test('keeps AI review topics without mutating the saved report', () => {
  const reported = [{ topic: 'Energy transfer', evidence: 'Your explanation needed more detail.' }];
  const snapshot = JSON.stringify(reported);
  const topics = buildReviewTopics(reported, [question], { q1: [answer('incorrect')] });
  assert.equal(topics.length, 2);
  assert.deepEqual(topics[0], reported[0]);
  assert.equal(JSON.stringify(reported), snapshot);
});

test('matching reported questions are not duplicated and use actual answer evidence', () => {
  const reported = [{ topic: ` ${question.prompt.toUpperCase()} `, evidence: 'Generic advice.' }];
  const topics = buildReviewTopics(reported, [question], { q1: [answer('partial'), answer('correct')] });
  assert.equal(topics.length, 1);
  assert.match(topics[0].evidence, /Your first answer/);
});

test('only questions in the current set contribute review items', () => {
  assert.deepEqual(buildReviewTopics([], [question], { oldQuestion: [answer('incorrect')] }), []);
});
