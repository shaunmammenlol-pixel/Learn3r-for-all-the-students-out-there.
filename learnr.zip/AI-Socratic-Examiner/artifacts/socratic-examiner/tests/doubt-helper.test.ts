import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import DoubtPanel from '../src/components/doubt-helper';

test('doubt composer has a spacious multiline input with accessible guidance', () => {
  const html = renderToStaticMarkup(createElement(DoubtPanel, { sourceMaterial: 'Example study notes.' }));
  assert.match(html, /<textarea[^>]+rows="4"/);
  assert.match(html, /<textarea[^>]+maxLength="2000"/i);
  assert.match(html, /data-testid="input-doubt"/);
  assert.match(html, /aria-describedby="helper-doubt-hint helper-doubt-count"/);
  assert.match(html, /resize-y/);
  assert.match(html, /Enter for a new line/);
  assert.match(html, /Ask helper/);
  assert.match(html, /data-doubt-state="idle"/);
});
