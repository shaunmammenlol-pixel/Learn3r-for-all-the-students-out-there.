import { test } from 'node:test';
import assert from 'node:assert/strict';
import { getStudyScrollTarget } from '../src/hooks/use-study-scroll';
import type { StudyScrollState } from '../src/hooks/use-study-scroll';

const quiz: StudyScrollState = {
  view: 'quiz', questionId: 'q1', attempts: 0, loading: false, complete: false, error: '',
};

test('opening a page or entering a quiz brings the relevant content into view', () => {
  assert.equal(getStudyScrollTarget(null, { ...quiz, view: 'study-guide' }), 'page');
  assert.equal(getStudyScrollTarget(null, quiz), 'question');
  assert.equal(getStudyScrollTarget(quiz, { ...quiz, view: 'report' }), 'page');
  assert.equal(getStudyScrollTarget({ ...quiz, view: 'dashboard' }, quiz), 'question');
});

test('new questions, submitted answers, and feedback each get the correct scroll target', () => {
  assert.equal(getStudyScrollTarget(quiz, { ...quiz, questionId: 'q2' }), 'question');
  assert.equal(getStudyScrollTarget(quiz, { ...quiz, loading: true }), 'loading');
  assert.equal(getStudyScrollTarget({ ...quiz, loading: true }, { ...quiz, attempts: 1 }), 'feedback');
  assert.equal(getStudyScrollTarget({ ...quiz, attempts: 1 }, { ...quiz, attempts: 2 }), 'feedback');
});

test('completion scrolls to the results and request failures bring the error into view', () => {
  assert.equal(getStudyScrollTarget(quiz, { ...quiz, complete: true, questionId: undefined }), 'page');
  assert.equal(getStudyScrollTarget(quiz, { ...quiz, error: 'Connection unavailable.' }), 'error');
});

test('typing, theme changes, and unrelated rerenders do not cause scrolling', () => {
  assert.equal(getStudyScrollTarget(quiz, { ...quiz }), null);
  assert.equal(getStudyScrollTarget({ ...quiz, loading: true }, quiz), null);
  const guide = { ...quiz, view: 'study-guide' };
  assert.equal(getStudyScrollTarget(guide, { ...guide, attempts: 1 }), null);
});
