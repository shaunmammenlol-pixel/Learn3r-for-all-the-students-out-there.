import { test } from 'node:test';
import assert from 'node:assert/strict';
import { quizFeedback, quizMotivation } from '../src/lib/quiz-feedback';

test('incorrect and partial feedback cannot expose generated or saved answer spoilers', () => {
  const spoiler = 'The correct answer is ATP and NADPH. You should choose option C.';
  for (const status of ['incorrect', 'partial'] as const) {
    for (let index = 0; index < 8; index++) {
      const feedback = quizFeedback(status, spoiler, index);
      assert.ok(feedback.length > 0);
      assert.ok(!feedback.includes('ATP'));
      assert.ok(!feedback.includes('option C'));
      assert.notEqual(feedback, spoiler);
    }
  }
});

test('correct answers keep the full explanation', () => {
  const explanation = 'Well done! ATP and NADPH are both named in your notes.';
  assert.equal(quizFeedback('correct', explanation), explanation);
});

test('retries receive varied, non-revealing guidance', () => {
  assert.notEqual(quizFeedback('incorrect', '', 0), quizFeedback('incorrect', '', 1));
  assert.match(quizFeedback('partial', '', 0), /part of the idea right/);
});

test('motivation covers the start, transitions, retries, and final question', () => {
  assert.match(quizMotivation(0, 3, false, 0), /Start with what you know/);
  assert.match(quizMotivation(0, 3, false, 1), /another try is normal/);
  assert.match(quizMotivation(0, 3, true, 1), /step forward/);
  assert.notEqual(quizMotivation(1, 3, false, 0), quizMotivation(2, 3, false, 0));
  assert.match(quizMotivation(2, 3, true, 2), /every question/);
  assert.match(quizMotivation(0, 1, true, 1), /every question/);
});
