import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { StudyQuestion, ChatMessage } from '@workspace/api-client-react';
import { earnedMarks, isSolved, migrateQuizProgress, quizScore, validQuestionAttempts } from '../src/lib/quiz-progress';
import type { QuizAttempt } from '../src/lib/quiz-progress';

const question = (id: string, marks: number): StudyQuestion => ({
  id, marks, kind: 'qa', prompt: 'Which two energy carriers are used?',
  correct_answer: 'ATP and NADPH', explanation: 'The material names both ATP and NADPH.',
});
const attempt = (status: QuizAttempt['status']): QuizAttempt => ({
  answer: status === 'correct' ? 'ATP and NADPH' : status === 'partial' ? 'ATP' : 'None',
  status, explanation: status === 'correct' ? 'Well done! Both are right.' : 'The material names ATP and NADPH. Try again.',
});

test('incorrect and partial answers do not unlock Next Question', () => {
  assert.equal(isSolved([]), false);
  assert.equal(isSolved([attempt('incorrect')]), false);
  assert.equal(isSolved([attempt('partial')]), false);
  assert.equal(isSolved([attempt('incorrect'), attempt('correct')]), true);
});

test('marks remain based on the first answer even after correct retries', () => {
  assert.equal(earnedMarks(question('q1', 5), [attempt('incorrect'), attempt('correct')]), 0);
  assert.equal(earnedMarks(question('q1', 5), [attempt('partial'), attempt('correct')]), 2);
  assert.equal(earnedMarks(question('q1', 5), [attempt('correct')]), 5);
  assert.equal(earnedMarks(question('q1', 1), [attempt('partial'), attempt('correct')]), 0);
});

test('total score uses all question weights without double-counting retries', () => {
  const questions = [question('one', 1), question('two', 5), question('three', 3)];
  assert.deepEqual(quizScore(questions, {
    one: [attempt('correct')], two: [attempt('incorrect'), attempt('correct')],
    three: [attempt('partial'), attempt('partial'), attempt('correct')],
  }), { earned: 2, available: 9 });
});

test('saved attempt history validates repeated attempts and rejects invalid data', () => {
  const questions = [question('q1', 3)];
  assert.equal(validQuestionAttempts({ q1: [attempt('incorrect'), attempt('partial'), attempt('correct')] }, questions), true);
  assert.equal(validQuestionAttempts({ missing: [attempt('correct')] }, questions), false);
  assert.equal(validQuestionAttempts({ q1: [{ ...attempt('correct'), answer: '' }] }, questions), false);
  assert.equal(validQuestionAttempts({ q1: [{ ...attempt('correct'), status: 'maybe' }] }, questions), false);
});

test('legacy progress keeps original answers and resumes at the first unsolved question', () => {
  const questions = [question('q1', 1), question('q2', 3)];
  const history: ChatMessage[] = [
    { id: 'p', role: 'assistant', kind: 'question', content: 'Question one' },
    { id: 'a', role: 'user', kind: 'answer', content: 'My first incorrect answer' },
    { id: 'f', role: 'assistant', kind: 'question', answer_status: 'incorrect', content: 'A kind explanation.\n\nQuestion 2 of 2\nQuestion two' },
    { id: 'a2', role: 'user', kind: 'answer', content: 'ATP and NADPH' },
    { id: 'f2', role: 'assistant', kind: 'feedback', answer_status: 'correct', content: 'Both carriers are right.' },
  ];
  const migrated = migrateQuizProgress(questions, history);
  assert.equal(migrated.question_index, 0);
  assert.equal(migrated.question_attempts.q1[0].answer, 'My first incorrect answer');
  assert.equal(migrated.question_attempts.q1[0].explanation, 'A kind explanation.');
  assert.equal(migrated.question_attempts.q2[0].status, 'correct');
});
