import { Router, type IRouter } from "express";
import healthRouter from "./health";
import examinerRouter from "./examiner";
import doubtsRouter from "./doubts";

const router: IRouter = Router();

router.use(healthRouter);
router.use(examinerRouter);
router.use(doubtsRouter);

export default router;
