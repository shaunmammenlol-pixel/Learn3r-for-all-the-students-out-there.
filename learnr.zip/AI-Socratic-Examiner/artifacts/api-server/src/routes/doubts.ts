import { Router, type IRouter } from "express";
import { ResolveDoubtBody, ResolveDoubtResponse } from "@workspace/api-zod";
import { AgenticOrgError, resolveDoubtWithAgent } from "../lib/agenticorg";

export function createDoubtsRouter(resolve: typeof resolveDoubtWithAgent = resolveDoubtWithAgent): IRouter {
const router: IRouter = Router();

router.post("/resolve-doubt", async (req, res): Promise<void> => {
  const input = ResolveDoubtBody.safeParse(req.body);
  if (!input.success || !input.data.source_material.trim() || !input.data.user_doubt.trim()) {
    const message = "Provide source material and a non-empty doubt within the input limits.";
    res.status(400).json(ResolveDoubtResponse.parse({
      status: "error", reply: message,
      error_code: "INVALID_CLIENT_DATA", message,
    }));
    return;
  }
  try {
    const result = await resolve(input.data);
    res.json(ResolveDoubtResponse.parse({ status: "success", reply: result.final_tutor_response }));
  } catch (error) {
    const failure = error instanceof AgenticOrgError
      ? error : new AgenticOrgError("AGENTICORG_PROVIDER_ERROR", "The doubt helper could not complete this request. Please try again later.", 502);
    req.log.warn({ error_code: failure.code, status: failure.status }, "Doubt helper request failed");
    res.status(failure.status).json(ResolveDoubtResponse.parse({
      status: "error", reply: failure.message,
      error_code: failure.code, message: failure.message,
    }));
  }
});

return router;
}

export default createDoubtsRouter();
