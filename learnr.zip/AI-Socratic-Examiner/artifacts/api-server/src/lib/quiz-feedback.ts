type AnswerStatus = 'correct' | 'partial' | 'incorrect';

/** Model grading stays authoritative, but unsuccessful feedback must not reveal the answer. */
export function studentQuizFeedback(status: AnswerStatus, explanation: string): string {
  if (status === 'correct') return `Well done—you got it right! ${explanation}`;
  if (status === 'partial') {
    return 'You’re on the right track, but there’s a little more to add. Check that your answer covers every part of the question, then try again. Take your time.';
  }
  return 'Not quite yet—and that’s okay. Reread the question and the relevant part of your notes, then try again in your own words. You can do this.';
}
