import pino from "pino";

const isProduction = process.env.NODE_ENV === "production";

export const logRedactionPaths = [
    "req.headers.authorization",
    "req.headers.cookie",
    "res.headers['set-cookie']",
    "req.headers['x-api-key']",
    "req.headers['api-key']",
    "apiKey",
    "api_key",
    "*.apiKey",
    "*.api_key",
    "GROQ_API_KEY",
    "GEMINI_API_KEY",
    "AGENTICORG_API_KEY",
    "SESSION_SECRET",
    "*.GROQ_API_KEY",
    "*.GEMINI_API_KEY",
    "*.AGENTICORG_API_KEY",
    "*.SESSION_SECRET",
];

export const logger = pino({
  level: process.env.LOG_LEVEL ?? "info",
  redact: logRedactionPaths,
  ...(isProduction
    ? {}
    : {
        transport: {
          target: "pino-pretty",
          options: { colorize: true },
        },
      }),
});
