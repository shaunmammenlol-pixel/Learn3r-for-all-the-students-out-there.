export interface GenerationAttempt {
  attempt: number;
  timeoutMs: number;
}

/** Retry a formatting failure once, within the original total time budget. */
export async function retryStructuredOutput<T>(
  generate: (context: GenerationAttempt) => Promise<T>,
  isFormatFailure: (error: unknown) => boolean,
  timeoutMs: number,
  now: () => number = Date.now,
): Promise<T> {
  const startedAt = now();
  try {
    return await generate({ attempt: 0, timeoutMs });
  } catch (error) {
    if (!isFormatFailure(error)) throw error;
    const remaining = timeoutMs - (now() - startedAt);
    if (remaining <= 0) throw error;
    return generate({ attempt: 1, timeoutMs: remaining });
  }
}

type Recovery<T> = { recovered: true; value: T } | { recovered: false };

/** Groq sometimes rejects its draft. Never use it unless our validator accepts it. */
export function recoverValidatedDraft<T>(
  failure: unknown,
  validate: (text: string) => T,
): Recovery<T> {
  if (typeof failure !== "object" || failure === null || !("error" in failure)) {
    return { recovered: false };
  }
  const error = failure.error;
  if (typeof error !== "object" || error === null ||
    !("code" in error) || error.code !== "json_validate_failed" ||
    !("failed_generation" in error) || typeof error.failed_generation !== "string") {
    return { recovered: false };
  }
  try {
    return { recovered: true, value: validate(error.failed_generation) };
  } catch {
    return { recovered: false };
  }
}
