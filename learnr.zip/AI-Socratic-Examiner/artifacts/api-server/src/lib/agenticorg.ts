import { z } from "zod";

const AGENT_RUN_URL = "https://app.agenticorg.ai/api/v1/agents/8e79f525-e7f6-45f0-9252-a3b79e4321ed/run";
const REVIEW_MESSAGE = "The Lead TA is currently reviewing this doubt manually. Please wait.";

interface DoubtInput {
  source_material: string;
  current_context?: string;
  user_doubt: string;
}

interface AgentReply {
  request_status: "success";
  status: "completed" | "hitl_triggered";
  final_tutor_response: string;
}

export class AgenticOrgError extends Error {
  constructor(readonly code: string, message: string, readonly status: number) {
    super(message);
    this.name = "AgenticOrgError";
  }
}

const envelopeSchema = z.object({
  status: z.enum(["completed", "hitl_triggered"]),
  output: z.unknown().optional(),
});
export function extractAgentReply(output: unknown): string {
  function unwrap(value: unknown, depth = 0): string | undefined {
    // Agent replies can contain JSON inside JSON, including inside message.
    if (depth > 8 || value == null) return undefined;
    if (typeof value === "string") {
      const text = value.trim().replace(/^```(?:json)?\s*([\s\S]*?)\s*```$/i, "$1").trim();
      if (!text) return undefined;
      if (text.startsWith("{") || text.startsWith("[") || text.startsWith('"')) {
        try {
          return unwrap(JSON.parse(text), depth + 1);
        } catch {
          return undefined;
        }
      }
      return text;
    }
    if (typeof value === "number" || value === true) return String(value);
    if (Array.isArray(value)) {
      return value.map((item) => unwrap(item, depth + 1)).filter(Boolean).join("\n\n") || undefined;
    }
    if (typeof value !== "object") return undefined;
    const fields = value as Record<string, unknown>;
    for (const key of ["answer", "message", "response", "final_tutor_response", "conversational_response", "final_response", "reply", "text", "content", "explanation", "output"]) {
      const reply = unwrap(fields[key], depth + 1);
      if (reply) return reply;
    }
    const fact = unwrap(fields.raw_fact, depth + 1);
    const analogy = unwrap(fields.analogy, depth + 1);
    return fact ? [fact, analogy && `A simple analogy:\n${analogy}`].filter(Boolean).join("\n\n") : undefined;
  }
  // Never render a provider envelope or metadata as the student's explanation.
  return unwrap(output) ?? "I couldn't process that doubt.";
}

export async function resolveDoubtWithAgent(
  input: DoubtInput,
  options: { apiKey?: string; fetchImpl?: typeof fetch } = {},
): Promise<AgentReply> {
  const apiKey = options.apiKey ?? process.env.AGENTICORG_API_KEY;
  if (!apiKey?.trim()) {
    throw new AgenticOrgError("AGENTICORG_NOT_CONFIGURED", "The doubt helper is not configured yet. Please ask the app owner to check the service configuration.", 503);
  }
  const constructedPrompt = `SOURCE NOTES:\n${input.source_material}\n\n${input.current_context ? `CURRENT CONTEXT:\n${input.current_context}\n\n` : ""}STUDENT DOUBT:\n${input.user_doubt}`;

  let response: Response;
  try {
    // No automatic retries: one request could create a human-review task.
    response = await (options.fetchImpl ?? fetch)(AGENT_RUN_URL, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ action: "process", inputs: { task: constructedPrompt }, context: {} }),
      signal: AbortSignal.timeout(30000),
    });
  } catch (error) {
    const timedOut = error instanceof Error && (error.name === "TimeoutError" || error.name === "AbortError");
    throw new AgenticOrgError(
      timedOut ? "AGENTICORG_TIMEOUT" : "AGENTICORG_PROVIDER_ERROR",
      timedOut ? "The doubt helper took too long to respond. Please try again later." : "The doubt helper could not be reached. Please try again later.",
      timedOut ? 504 : 502,
    );
  }
  if (!response.ok) {
    throw new AgenticOrgError("AGENTICORG_PROVIDER_ERROR",
      response.status === 401 || response.status === 403
        ? "The doubt helper could not authorize this request. Please ask the app owner to check the service configuration."
        : response.status === 404
          ? "AgenticOrg could not find this agent or endpoint (HTTP 404). The app owner should verify the agent run URL and this API key's access to the agent."
        : response.status === 429
          ? "The doubt helper has reached a usage limit. Please try again later."
          : "The doubt helper service could not complete this request. Please try again later.",
      502);
  }
  try {
    const data = envelopeSchema.parse(await response.json());
    if (data.status === "hitl_triggered") {
      return { request_status: "success", status: data.status, final_tutor_response: REVIEW_MESSAGE };
    }
    const tutorResponse = extractAgentReply(data.output);
    return { request_status: "success", status: "completed", final_tutor_response: tutorResponse };
  } catch {
    throw new AgenticOrgError("AGENTICORG_FORMAT_FAILURE", "The doubt helper returned an unreadable or incomplete response. Please try again later.", 502);
  }
}
