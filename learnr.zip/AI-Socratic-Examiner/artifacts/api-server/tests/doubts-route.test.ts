import { test } from "node:test";
import assert from "node:assert/strict";
import express from "express";
import { createDoubtsRouter } from "../src/routes/doubts";
import { AgenticOrgError, resolveDoubtWithAgent } from "../src/lib/agenticorg";

test("doubt route accepts the two-field panel request and returns status/reply for every outcome", async () => {
  const calls: unknown[] = [];
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.log = { warn: () => {} } as typeof req.log;
    next();
  });
  app.use("/api", createDoubtsRouter(async (input) => {
    calls.push(input);
    if (input.user_doubt === "fail") throw new AgenticOrgError("AGENTICORG_PROVIDER_ERROR", "Agent unavailable.", 502);
    if (input.user_doubt === "completed-shape") {
      return resolveDoubtWithAgent(input, {
        apiKey: "test-key",
        fetchImpl: async () => new Response(JSON.stringify({
          status: "completed", output: JSON.stringify({
            status: "success",
            compliance_flag: "compliant",
            message: "Chlorophyll acts like the plant's solar panels.",
          }),
        })),
      });
    }
    return {
      request_status: "success",
      status: input.user_doubt === "review" ? "hitl_triggered" : "completed",
      final_tutor_response: input.user_doubt === "review"
        ? "The Lead TA is currently reviewing this doubt manually. Please wait."
        : "It means taking in light.",
    };
  }));
  const server = app.listen(0, "127.0.0.1");
  await new Promise<void>((resolve) => server.once("listening", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  async function post(body: unknown) {
    const response = await fetch(`http://127.0.0.1:${(address as { port: number }).port}/api/resolve-doubt`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    return { status: response.status, data: await response.json() };
  }
  try {
    const body = { source_material: "Chlorophyll absorbs light.", user_doubt: "Explain absorbs." };
    assert.deepEqual(await post(body), { status: 200, data: { status: "success", reply: "It means taking in light." } });
    assert.deepEqual(calls[0], body);
    assert.deepEqual(await post({ ...body, user_doubt: "completed-shape" }), {
      status: 200, data: { status: "success", reply: "Chlorophyll acts like the plant's solar panels." },
    });
    assert.deepEqual(await post({ ...body, user_doubt: "review" }), {
      status: 200, data: { status: "success", reply: "The Lead TA is currently reviewing this doubt manually. Please wait." },
    });
    const failed = await post({ ...body, user_doubt: "fail" });
    assert.equal(failed.status, 502);
    assert.equal(failed.data.status, "error");
    assert.equal(failed.data.reply, "Agent unavailable.");
    for (const invalid of [{ ...body, user_doubt: " " }, { user_doubt: "Explain." }, { ...body, source_material: "x".repeat(5001) }]) {
      const result = await post(invalid);
      assert.equal(result.status, 400);
      assert.equal(result.data.status, "error");
      assert.ok(result.data.reply);
    }
    assert.equal(calls.length, 4, "invalid inputs never reach the agent");
  } finally {
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
});
