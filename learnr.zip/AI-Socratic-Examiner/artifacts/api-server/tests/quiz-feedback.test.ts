import { test } from 'node:test';
import assert from 'node:assert/strict';
import { studentQuizFeedback } from '../src/lib/quiz-feedback';

test('unsuccessful grading never returns an answer leaked by the model', () => {
  for (const status of ['incorrect', 'partial'] as const) {
    const feedback = studentQuizFeedback(status, 'The correct answer is chlorophyll. Choose B.');
    assert.ok(!feedback.includes('chlorophyll'));
    assert.ok(!feedback.includes('Choose B'));
    assert.match(feedback, /try again/);
  }
});

test('successful grading still congratulates and explains the correct answer', () => {
  assert.equal(studentQuizFeedback('correct', 'Chlorophyll absorbs light.'),
    'Well done—you got it right! Chlorophyll absorbs light.');
});
