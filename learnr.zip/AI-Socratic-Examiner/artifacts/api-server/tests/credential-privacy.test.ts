import { test } from "node:test";
import assert from "node:assert/strict";
import { Writable } from "node:stream";
import pino from "pino";
import { logRedactionPaths } from "../src/lib/logger";
import { AgenticOrgError, resolveDoubtWithAgent } from "../src/lib/agenticorg";

test("structured logs redact credentials and authorization headers", () => {
  const records: string[] = [];
  const stream = new Writable({
    write(chunk, _encoding, done) { records.push(String(chunk)); done(); },
  });
  const log = pino({ redact: logRedactionPaths }, stream);
  const dummy = "test-private-value-not-a-real-key";
  log.info({
    apiKey: dummy, api_key: dummy,
    GROQ_API_KEY: dummy, GEMINI_API_KEY: dummy,
    AGENTICORG_API_KEY: dummy, SESSION_SECRET: dummy,
    settings: {
      apiKey: dummy, api_key: dummy, GROQ_API_KEY: dummy,
      GEMINI_API_KEY: dummy, AGENTICORG_API_KEY: dummy, SESSION_SECRET: dummy,
    },
    req: { headers: { authorization: `Bearer ${dummy}`, "x-api-key": dummy, "api-key": dummy, cookie: dummy } },
    res: { headers: { "set-cookie": dummy } },
  }, "Credential redaction test");
  assert.ok(records.length > 0);
  assert.ok(!records.join("").includes(dummy));
  assert.match(records.join(""), /redacted/i);
});

test("missing-service errors do not expose credential configuration details", async () => {
  await assert.rejects(resolveDoubtWithAgent({
    source_material: "Plants absorb light.", user_doubt: "Explain absorb.",
  }, { apiKey: "" }), (error) => {
    assert.ok(error instanceof AgenticOrgError);
    assert.equal(error.status, 503);
    assert.ok(!error.message.includes("API_KEY"));
    return true;
  });
});

test("authorization errors do not forward provider bodies or key names", async () => {
  await assert.rejects(resolveDoubtWithAgent({
    source_material: "Plants absorb light.", user_doubt: "Explain absorb.",
  }, {
    apiKey: "test-placeholder",
    fetchImpl: async () => new Response("Private provider diagnostics", { status: 401 }),
  }), (error) => {
    assert.ok(error instanceof AgenticOrgError);
    assert.ok(!error.message.includes("API_KEY"));
    assert.ok(!error.message.includes("Private provider diagnostics"));
    return true;
  });
});
