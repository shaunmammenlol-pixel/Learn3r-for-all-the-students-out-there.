import { test } from "node:test";
import assert from "node:assert/strict";
import { recoverValidatedDraft, retryStructuredOutput } from "../src/lib/structured-output";

const formatError = () => Object.assign(new Error("Invalid model output"), { code: "LLM_FORMAT_FAILURE" });
const isFormat = (error: unknown) => error instanceof Error && "code" in error && error.code === "LLM_FORMAT_FAILURE";

test("successful responses need only one request", async () => {
  let calls = 0;
  const result = await retryStructuredOutput(async ({ attempt }) => {
    calls++;
    assert.equal(attempt, 0);
    return "valid";
  }, isFormat, 1000);
  assert.equal(result, "valid");
  assert.equal(calls, 1);
});

test("format failure retries once with only the remaining time", async () => {
  let time = 0;
  const attempts: { attempt: number; timeoutMs: number }[] = [];
  const result = await retryStructuredOutput(async (context) => {
    attempts.push(context);
    if (!context.attempt) { time = 200; throw formatError(); }
    return "validated";
  }, isFormat, 1000, () => time);
  assert.equal(result, "validated");
  assert.deepEqual(attempts, [{ attempt: 0, timeoutMs: 1000 }, { attempt: 1, timeoutMs: 800 }]);
});

test("two malformed responses fail without a third request or invented data", async () => {
  let calls = 0;
  await assert.rejects(retryStructuredOutput(async () => {
    calls++;
    throw formatError();
  }, isFormat, 1000), /Invalid model output/);
  assert.equal(calls, 2);
});

for (const code of ["RATE_LIMIT", "AUTHENTICATION", "TIMEOUT"]) {
  test(`${code} is never retried`, async () => {
    let calls = 0;
    const failure = Object.assign(new Error(code), { code });
    await assert.rejects(retryStructuredOutput(async () => { calls++; throw failure; }, isFormat, 1000), (error) => error === failure);
    assert.equal(calls, 1);
  });
}

test("an exhausted deadline prevents a second request", async () => {
  let time = 0;
  let calls = 0;
  await assert.rejects(retryStructuredOutput(async () => {
    calls++;
    time = 1000;
    throw formatError();
  }, isFormat, 1000, () => time), /Invalid model output/);
  assert.equal(calls, 1);
});

function validateGuide(text: string) {
  const parsed: unknown = JSON.parse(text);
  if (typeof parsed !== "object" || parsed === null || !("summary" in parsed) || typeof parsed.summary !== "string" || !parsed.summary) {
    throw Error("Invalid guide");
  }
  return parsed;
}

test("a provider-rejected draft is recoverable only after successful validation", () => {
  assert.deepEqual(recoverValidatedDraft({
    error: { code: "json_validate_failed", failed_generation: '{"summary":"A supported explanation."}' },
  }, validateGuide), { recovered: true, value: { summary: "A supported explanation." } });
});

for (const draft of ['{"summary":', '{"summary":42}', '{}']) {
  test(`rejects incomplete or structurally invalid draft ${draft}`, () => {
    assert.deepEqual(recoverValidatedDraft({
      error: { code: "json_validate_failed", failed_generation: draft },
    }, validateGuide), { recovered: false });
  });
}

test("draft recovery never bypasses a different provider error", () => {
  assert.deepEqual(recoverValidatedDraft({
    error: { code: "authentication_error", failed_generation: '{"summary":"Not permitted"}' },
  }, validateGuide), { recovered: false });
});
