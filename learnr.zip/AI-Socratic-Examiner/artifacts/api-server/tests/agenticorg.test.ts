import { test } from "node:test";
import assert from "node:assert/strict";
import { AgenticOrgError, resolveDoubtWithAgent } from "../src/lib/agenticorg";

const input = { source_material: "Chlorophyll absorbs light.", user_doubt: "What does absorbs mean here?" };
const responseFetch = (body: unknown, status = 200): typeof fetch => async () =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

test("uses standard fetch with the exact agent endpoint, auth, and body envelope", async () => {
  let calls = 0;
  const result = await resolveDoubtWithAgent(input, {
    apiKey: "test-key",
    fetchImpl: async (url, options) => {
      calls++;
      assert.equal(url, "https://app.agenticorg.ai/api/v1/agents/8e79f525-e7f6-45f0-9252-a3b79e4321ed/run");
      assert.equal(options?.method, "POST");
      assert.deepEqual(options?.headers, { Authorization: "Bearer test-key", "Content-Type": "application/json" });
      const body = JSON.parse(String(options?.body));
      assert.deepEqual(Object.keys(body).sort(), ["action", "context", "inputs"]);
      assert.equal(body.action, "process");
      assert.deepEqual(body.context, {});
      assert.deepEqual(Object.keys(body.inputs), ["task"]);
      assert.equal(body.inputs.task, `SOURCE NOTES:\n${input.source_material}\n\nSTUDENT DOUBT:\n${input.user_doubt}`);
      for (const value of Object.values(input)) assert.ok(body.inputs.task.includes(value));
      assert.ok(options?.signal instanceof AbortSignal);
      return new Response(JSON.stringify({ status: "completed", output: { answer: "It means taking in light." } }));
    },
  });
  assert.equal(calls, 1);
  assert.deepEqual(result, { request_status: "success", status: "completed", final_tutor_response: "It means taking in light." });
});

test("human review returns the exact message without requiring or parsing output", async () => {
  assert.deepEqual(await resolveDoubtWithAgent(input, {
    apiKey: "test-key", fetchImpl: responseFetch({ status: "hitl_triggered", output: "not JSON" }),
  }), { request_status: "success", status: "hitl_triggered", final_tutor_response: "The Lead TA is currently reviewing this doubt manually. Please wait." });
});

test("extracts the tutor explanation instead of serializing its object", async () => {
  const result = await resolveDoubtWithAgent(input, {
    apiKey: "test-key", fetchImpl: responseFetch({ status: "completed", output: { final_tutor_response: "A simple explanation." } }),
  });
  assert.equal(result.final_tutor_response, "A simple explanation.");
});

for (const field of ["conversational_response", "final_response"]) {
for (const encoding of ["object", "JSON string"]) {
  test(`accepts the live agent's ${field} (${encoding}) without leaking metadata`, async () => {
    const output = {
      raw_fact: "Chlorophyll absorbs light during photosynthesis.",
      analogy: "Solar panels capture sunlight.",
      [field]: "Think of chlorophyll as the plant's solar panels: it captures sunlight.",
    };
    const result = await resolveDoubtWithAgent(input, {
      apiKey: "test-key",
      fetchImpl: responseFetch({
        status: "completed",
        output: encoding === "object" ? output : JSON.stringify(output),
        reasoning_trace: ["Internal diagnostic data"],
      }),
    });
    assert.equal(result.final_tutor_response, output[field]);
    assert.equal(result.status, "completed");
    assert.ok(!result.final_tutor_response.includes("reasoning_trace"));
    assert.equal(typeof result.final_tutor_response, "string");
  });
}
}

test("fact and analogy become readable text without confidence metadata", async () => {
  const result = await resolveDoubtWithAgent(input, {
    apiKey: "test-key",
    fetchImpl: responseFetch({ status: "completed", output: {
      raw_fact: "Chlorophyll absorbs light.",
      analogy: "It works like solar panels.",
      confidence: 0.9,
    } }),
  });
  assert.equal(result.final_tutor_response, "Chlorophyll absorbs light.\n\nA simple analogy:\nIt works like solar panels.");
});

test("answer takes priority over message and response", async () => {
  const result = await resolveDoubtWithAgent(input, {
    apiKey: "test-key",
    fetchImpl: responseFetch({ status: "completed", output: {
      answer: "The primary answer.",
      message: "An alternative message.",
      response: "An alternative response.",
    } }),
  });
  assert.equal(result.final_tutor_response, "The primary answer.");
});

for (const output of [{ conversational_response: "" }, { status: "success", compliance_flag: "compliant" }, { confidence: 0.9 }]) {
  test(`metadata without an explanation is not displayed (${JSON.stringify(output)})`, async () => {
    const result = await resolveDoubtWithAgent(input, {
      apiKey: "test-key", fetchImpl: responseFetch({ status: "completed", output }),
    });
    assert.equal(result.final_tutor_response, "I couldn't process that doubt.");
  });
}

test("completed plain-text output becomes a safe tutor reply", async () => {
  const result = await resolveDoubtWithAgent(input, {
    apiKey: "test-key", fetchImpl: responseFetch({ status: "completed", output: "It means taking in light." }),
  });
  assert.equal(result.final_tutor_response, "It means taking in light.");
});

for (const output of ['{"final_tutor_response":', "{}", '{"final_tutor_response":""}', '{"final_tutor_response":5}', "", null, undefined]) {
  test(`text output remains a string with a fallback for missing output (${String(output)})`, async () => {
    const result = await resolveDoubtWithAgent(input, {
      apiKey: "test-key", fetchImpl: responseFetch({ status: "completed", output }),
    });
    assert.equal(result.final_tutor_response, output === '{"final_tutor_response":5}' ? "5" : "I couldn't process that doubt.");
  });
}

for (const [output, expected] of [
  [{ message: "A message.", response: "A response." }, "A message."],
  [{ answer: "", response: "A response." }, "A response."],
  [{ answer: { explanation: "A nested answer." } }, "A nested answer."],
  [["One", "Two"], "One\n\nTwo"],
  [42, "42"],
  [true, "true"],
  [false, "I couldn't process that doubt."],
  ["   ", "I couldn't process that doubt."],
] as const) {
  test(`reply extraction always returns displayable text (${JSON.stringify(output)})`, async () => {
    const result = await resolveDoubtWithAgent(input, {
      apiKey: "test-key", fetchImpl: responseFetch({ status: "completed", output }),
    });
    assert.equal(result.final_tutor_response, expected);
  });
}

const wrappedExplanation = {
  status: "success",
  compliance_flag: "compliant",
  message: "Chlorophyll takes in light so the plant can use its energy.",
};
for (const output of [
  wrappedExplanation,
  JSON.stringify(wrappedExplanation),
  JSON.stringify(JSON.stringify(wrappedExplanation)),
  { message: JSON.stringify(wrappedExplanation) },
  { response: { output: JSON.stringify(wrappedExplanation) } },
  `\`\`\`json\n${JSON.stringify(wrappedExplanation)}\n\`\`\``,
]) {
  test(`unwraps the reported compliance envelope (${typeof output === "string" ? "encoded" : "object"})`, async () => {
    const result = await resolveDoubtWithAgent(input, {
      apiKey: "test-key", fetchImpl: responseFetch({ status: "completed", output }),
    });
    assert.equal(result.final_tutor_response, wrappedExplanation.message);
    assert.ok(!result.final_tutor_response.includes("compliance_flag"));
    assert.ok(!result.final_tutor_response.includes('"status"'));
  });
}

test("excessive nesting stops safely instead of displaying JSON", async () => {
  let output: unknown = wrappedExplanation;
  for (let depth = 0; depth < 15; depth++) output = { message: output };
  const result = await resolveDoubtWithAgent(input, {
    apiKey: "test-key", fetchImpl: responseFetch({ status: "completed", output }),
  });
  assert.equal(result.final_tutor_response, "I couldn't process that doubt.");
});

test("unknown status and invalid envelope are not treated as completion", async () => {
  for (const body of [{ status: "running" }, {}, null]) {
    await assert.rejects(resolveDoubtWithAgent(input, { apiKey: "test-key", fetchImpl: responseFetch(body) }), AgenticOrgError);
  }
});

test("missing configuration fails before any external request", async () => {
  let called = false;
  await assert.rejects(resolveDoubtWithAgent(input, { apiKey: "", fetchImpl: async () => { called = true; throw Error("Unexpected fetch"); } }),
    (error) => error instanceof AgenticOrgError && error.status === 503);
  assert.equal(called, false);
});

test("network errors are safe and never automatically retried", async () => {
  let calls = 0;
  await assert.rejects(resolveDoubtWithAgent(input, {
    apiKey: "test-key", fetchImpl: async () => { calls++; throw Error("Internal transport details"); },
  }), (error) => error instanceof AgenticOrgError && error.code === "AGENTICORG_PROVIDER_ERROR" && !error.message.includes("Internal transport"));
  assert.equal(calls, 1);
});

test("timeouts are reported explicitly", async () => {
  await assert.rejects(resolveDoubtWithAgent(input, {
    apiKey: "test-key", fetchImpl: async () => { throw new DOMException("Timeout", "TimeoutError"); },
  }), (error) => error instanceof AgenticOrgError && error.status === 504);
});

for (const status of [401, 403, 404, 429, 500]) {
  test(`HTTP ${status} fails without exposing the provider body`, async () => {
    await assert.rejects(resolveDoubtWithAgent(input, {
      apiKey: "test-key", fetchImpl: responseFetch({ internal: "private provider details" }, status),
    }), (error) => error instanceof AgenticOrgError && error.status === 502 && !error.message.includes("private provider")
      && (status !== 404 || error.message.includes("verify the agent run URL")));
  });
}
