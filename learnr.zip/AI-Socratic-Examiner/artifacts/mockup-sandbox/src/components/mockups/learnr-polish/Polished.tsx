import {useState} from 'react';
import {BookOpen,PanelTop,CircleHelp,FileText,Moon,Sun} from 'lucide-react';
import './_polished.css';
type AppView='input'|'study-guide'|'dashboard'|'quiz'|'report'|'setup';
export default function Polished(){
const[currentView,navigate]=useState<AppView>('study-guide');
const[theme,setTheme]=useState<'light'|'dark'>(new URLSearchParams(window.location.search).get('theme')==='dark'?'dark':'light');
const session={source_material:'Sample study notes',study_guide_seen:true,report_result:{},theme};
const resetStudy=()=>navigate('input');
const toggleTheme=()=>setTheme(previous=>previous==='light'?'dark':'light');
  const navItems: { view: AppView; label: string; icon: typeof PanelTop }[] = [
    { view: 'study-guide', label: 'Study guide', icon: BookOpen },
    { view: 'dashboard', label: 'Overview', icon: PanelTop },
    { view: 'quiz', label: 'Study session', icon: CircleHelp },
    { view: 'report', label: 'Study report', icon: FileText },
  ];
return <div className={theme==='dark'?'dark min-h-screen bg-background text-foreground':'min-h-screen bg-background text-foreground'}><header className="topbar sticky top-0 z-20">
        <div className="page-wrap flex min-h-[72px] items-center justify-between gap-4">
          <button className="flex items-center gap-3 text-left" onClick={() => navigate('input')} data-testid="link-home" aria-label="Go to source material input">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary text-primary-foreground"><BookOpen size={19} /></span>
            <span>
              <span className="block text-[15px] font-bold tracking-tight">learnr</span>
              <span className="block text-[11px] text-muted-foreground">Study from your own notes</span>
            </span>
          </button>
          <nav aria-label="Study navigation" className="hidden items-center gap-1 md:flex">
            {navItems.map(({ view, label, icon: Icon }) => (
              <button key={view} className={`nav-link flex items-center gap-2 rounded-lg px-3 py-2 text-[13px] font-semibold ${currentView === view ? 'active' : ''}`}
                onClick={() => navigate(view)} disabled={!session.source_material || (view === 'quiz' && !session.study_guide_seen) || (view === 'report' && !session.report_result)} data-testid={`nav-${view}`}>
                <Icon size={15} />{label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            {session.source_material && <button className="quiet-button hidden rounded-lg px-3 py-2 text-xs font-semibold sm:inline-flex" onClick={resetStudy} data-testid="button-new-study">New study</button>}
            <button className="theme-switch quiet-button inline-flex h-10 items-center gap-2 rounded-xl px-2.5" onClick={toggleTheme} role="switch" aria-checked={session.theme === 'dark'} aria-label={`Switch to ${session.theme === 'light' ? 'dark' : 'light'} mode`} data-testid="button-theme-toggle">
              {session.theme === 'light' ? <Moon size={15} /> : <Sun size={15} />}
              <span className="text-xs font-semibold">{session.theme === 'light' ? 'Light' : 'Dark'}</span>
              <span aria-hidden="true" className={`theme-switch-track ${session.theme === 'dark' ? 'is-dark' : ''}`}><span className="theme-switch-thumb" /></span>
            </button>
          </div>
        </div>
        <nav aria-label="Study navigation" className="page-wrap flex gap-1 overflow-x-auto pb-2 md:hidden">
          {navItems.map(({ view, label }) => (
            <button key={view} className={`nav-link whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-semibold ${currentView === view ? 'active' : ''}`}
                onClick={() => navigate(view)} disabled={!session.source_material || (view === 'quiz' && !session.study_guide_seen) || (view === 'report' && !session.report_result)} data-testid={`mobile-nav-${view}`}>{label}</button>
          ))}
          {session.source_material && <button className="nav-link whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-semibold" onClick={resetStudy} data-testid="mobile-button-new-study">New study</button>}
        </nav>
      </header></div>;
}
