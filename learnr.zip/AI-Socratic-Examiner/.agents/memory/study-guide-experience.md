---
name: Study guide experience
description: User requirements for understandable, exam-oriented study guides
---
Make summaries easy to understand with an everyday analogy. Do not repeat the original source text in study screens. Give concrete improvement advice and exam-style revision priorities.

**Why:** The user explicitly requested simpler explanations, analogies, removal of the source-text section, and guidance on improving and preparing for exams.

**How to apply:** Keep analogies clearly labelled as learning aids rather than examinable facts. Base revision priorities and sample questions on the supplied material; do not claim to predict the actual exam. Retain source material internally for grounding.

Bring each new page, quiz question, and answer feedback into view automatically instead of leaving students at the previous scroll position.

**Why:** The user explicitly asked to scroll back up for every quiz question/answer and on navigation, to make the experience more user-friendly.

**How to apply:** Keep content clear of the sticky header, respect reduced-motion preferences, and do not interrupt typing or make unrelated doubt-chat updates move the whole page.
