---
name: AI provider decisions
description: Provider choice and reliability constraints for examiner generation
---
The user chose Groq after encountering Gemini's daily free-tier quota. Do not silently fall back to Gemini, paid managed AI, or device-local models when Groq is unavailable. Do not describe hosted AI as unlimited free usage.

**Why:** The user wanted an alternative to their quota-limited Gemini service and explicitly selected Groq; a local-model switch was not approved.

**How to apply:** Keep the active provider's credentials server-side and report its own quota or authorization errors clearly. A provider change must retain source-grounded questions and all study-guide fields.

AgenticOrg is a separate doubt-resolution helper, not a replacement for Groq's main examiner flow.

**Why:** The user explicitly requested the Pine Labs AgenticOrg agent as a helper bot with manual Lead TA review support.

**How to apply:** Use the requested AgenticOrg process-run contract only for doubts. Never automatically retry these submissions: a run can create a real human-review task. A manual-review response must not be presented as a completed tutor answer.

Require an explicit provider response schema as well as local semantic validation.

**Why:** JSON MIME mode alone allowed missing or mistyped required fields, blocking entry to the study flow.

**How to apply:** Use a model's supported structured-output mode rather than silently accepting malformed responses. Validate rules that JSON schemas cannot express, including requested question counts and matching MCQ answer options.

Encode requested per-type question counts as structural constraints, not only instructions in a prompt.

**Why:** A strict generic question-array schema still allowed the model to return the wrong MCQ/Q&A split for a maximum-sized mixed session. Increasing the response budget alone did not solve it.

**How to apply:** Constrain the MCQ and written groups separately to their requested lengths and kinds, validate both, and only then interleave them for display. Preserve empty groups for single-type sessions.

Groq strict structured-output requests can still fail intermittently with `json_validate_failed`; prior successful examples do not prove the path is reliable.

**Why:** A learner hit this provider rejection during study-guide preparation after live checks had passed.

**How to apply:** A rejected draft is usable only after full local validation. Otherwise allow at most one format-only retry within the original total timeout. Never retry quota, authentication, or network errors through this recovery path, and never invent replacement study content.
