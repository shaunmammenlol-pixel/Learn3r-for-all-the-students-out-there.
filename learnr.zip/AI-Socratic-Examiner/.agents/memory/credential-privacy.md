---
name: Provider credential privacy
description: User-required API key privacy throughout learnr
---
Hide all API keys from students and other app visitors.

**Why:** The user explicitly requested “hide all the api keys.”

**How to apply:** Keep credentials server-side, out of browser bundles and public error details. Never log or display key values. Avoid committing or publishing local credential files. A previously shared key still needs rotation; hiding it does not revoke existing copies.
