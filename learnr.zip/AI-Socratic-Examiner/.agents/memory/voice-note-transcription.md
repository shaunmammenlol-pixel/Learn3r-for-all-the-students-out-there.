---
name: Voice-note transcription
description: User-specified provider for uploaded voice-note transcription
---
Use Puter.js for transcribing uploaded voice notes.

**Why:** The user explicitly requested Puter.js and supplied its v2 script URL; this is separate from the Gemini examiner provider.

**How to apply:** Keep audio transcription on the requested provider unless the user changes this choice. Explain that audio leaves the browser and that Puter may require its own authorization.
