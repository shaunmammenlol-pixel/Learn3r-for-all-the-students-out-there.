---
name: Product identity
description: User-specified public name and casing for the learning app.
---

The app is named **learnr**, lowercase.

**Why:** The user explicitly requested this name for the existing learning app.

**How to apply:** Use learnr in user-facing branding and metadata. Keep persistent study-session identifiers stable during branding changes so existing progress is preserved.
