---
name: Doubt bot scope and state
description: User-required scope separation and strict string-state policy for the doubt chat.
---

The Raise Hand / Ask Doubt feature is specifically for the doubt bot, not the examiner or scoring flow. Its request state must use `DoubtState` with `"idle"`, `"loading"`, `"success"`, and `"error"`; do not use boolean variables for state.

**Why:** The user emphasized “THIS IS FOR THE DOUBT BOT” and supplied guidelines with critical enforcement of the no-boolean state rule.

**How to apply:** Preserve the chat-style user/agent conversation and explicit request-state transitions. Keep doubt-bot changes separate from quiz progression and marking.

Use the default AgenticOrg SDK host, `app.agenticorg.ai`, not the hackathon host from earlier pasted examples.

**Why:** The user explicitly replaced the hackathon endpoint with the default SDK URL.

**How to apply:** Do not restore the obsolete hackathon hostname when consulting older uploaded instructions.

Completed AgenticOrg replies can vary in structure between runs, even for the same question. Treat the agent's output contract as variable rather than assuming one tutor-message key.

**Why:** Live runs supplied valid student-facing explanations under different field names, which a single-field parser incorrectly rejected as format errors.

**How to apply:** Keep representative response fixtures and extract student-facing explanation text from objects and JSON-encoded strings, including nested message wrappers. Never display serialized envelopes, status/compliance fields, or other metadata as the explanation; use a readable fallback when no explanation is available.

Show only the doubt helper's explanation, not JSON prefixes such as `{"status":"success","compliance_flag":"compliant","message":...}`.

**Why:** The user explicitly reported these prefixes appearing on every doubt and asked to remove them. This supersedes the earlier request for a generic JSON-stringification fallback.

**How to apply:** Normalize structured replies before sending them to the chat; do not fix the display by merely deleting a fixed prefix, since nested and encoded envelopes vary.
