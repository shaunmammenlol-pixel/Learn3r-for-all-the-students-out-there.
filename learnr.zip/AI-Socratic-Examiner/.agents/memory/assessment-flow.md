---
name: Assessment flow
description: User-defined answer handling and question-set choices
---
Wrong answers must receive a simple, empathetic, compassionate explanation and encouragement to try again on the same question. A partly correct but incomplete answer also stays on that question, while acknowledging what is right. Continue until correct. On a correct answer, congratulate the learner and briefly explain why it is right.

During the quiz, incorrect and partly correct feedback must not reveal the correct choice, missing answer terms, or full solution. Give non-revealing retry guidance instead. Add short encouragement between questions and after retries. Full answer explanations belong after a correct response or in the final review.

**Why:** The user asked for motivation between quiz questions and reported the AI revealing answers during attempts.

**How to apply:** Do not rely on a model prompt alone to prevent spoilers. Keep unsuccessful feedback non-revealing in both server responses and the active-quiz display, including feedback restored from older sessions. Leave grading, marks, and the separate doubt helper unchanged.

Never advance automatically. Only show the next question after the learner clicks Next Question following a correct answer.

Before questions start, let the learner choose Quiz (MCQs), Q&A (written answers), or Mixed and choose question counts. Mixed asks separately for MCQs and Q&A. The maximum is 20 questions total for a set. Each question has 1–5 marks. At the end show a total score and review the learner's answers, expected answers, and where mistakes occurred.

**Why:** The user explicitly replaced the earlier explain-and-advance policy with retry-until-correct and manual progression.

**How to apply:** Enforce correct-answer gating in both the rendered controls and state transitions. Preserve attempts and question position across reloads. Keep the study guide before setup/questions and enforce count limits in the UI and server.

The score is based on the first submitted answer: correct earns full marks, partial earns half rounded down, and incorrect earns zero. Later attempts are practice and do not inflate earned marks. Show this rule before submission and in the results.

**Why:** A first-attempt score stays meaningful even though every learner is supported until they answer correctly. This is an implementation choice, not a scoring rule the user explicitly specified; change it if they request another policy.

**How to apply:** Keep original and later attempts in the final review, and keep scoring separate from whether the learner has eventually understood the answer.

The report's “Review again” section should retain questions with incorrect or partly correct first answers, even after successful retries or when the AI lists no misunderstood topics.

**Why:** Retry-until-correct can make an AI report emphasize eventual success and omit useful revision needs. The user reported an empty review column; recorded answers provide reliable revision evidence.

**How to apply:** Present these as topics to reinforce, not claims that the learner still misunderstands them. Include the original answer, expected answer, and explanation. Do not invent mistakes for correct first answers or unanswered questions.
