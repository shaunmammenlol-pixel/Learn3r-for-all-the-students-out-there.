---
name: Question scope
description: User-defined limits for examiner questions
---
Questions must be strictly based on the supplied material.

**Why:** The user explicitly requested material-only questions; a live generation asked for an inferred conclusion despite an initial source-only instruction.

**How to apply:** Prefer direct comprehension of stated details and explicit comparisons. Do not require outside knowledge or introduce unsupported conclusions, scenarios, or assumptions.
